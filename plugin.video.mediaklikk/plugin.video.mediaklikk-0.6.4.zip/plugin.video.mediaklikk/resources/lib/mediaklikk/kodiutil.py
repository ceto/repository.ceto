"""Thin adapter over the Kodi API.

Everything that touches xbmc* modules lives here (and in router.py), so the
rest of the library stays importable and testable outside Kodi.
"""
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_VERSION = ADDON.getAddonInfo("version")


def localize(string_id):
    return ADDON.getLocalizedString(string_id)


def setting_bool(key, default=False):
    try:
        return ADDON.getSettingBool(key)
    except Exception:  # setting missing or wrong type
        return default


def debug_enabled():
    return setting_bool("debug_logging")


def log(message, level=None):
    """Log to kodi.log. Debug messages are promoted to INFO when the add-on's
    own debug setting is on, so they show up without enabling Kodi debug mode.
    Callers must never pass player tokens or stream URLs."""
    if level is None:
        level = xbmc.LOGINFO if debug_enabled() else xbmc.LOGDEBUG
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)


def log_error(message):
    xbmc.log("[%s] %s" % (ADDON_ID, message), xbmc.LOGERROR)


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, time_ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, time_ms)


def notify_error(message):
    notify(message, xbmcgui.NOTIFICATION_ERROR, 6000)


def keyboard(heading):
    """Text input; returns None when cancelled or empty."""
    text = xbmcgui.Dialog().input(heading, type=xbmcgui.INPUT_ALPHANUM)
    return (text or "").strip() or None


def profile_path(*parts):
    """Absolute path inside the add-on's profile folder (special://profile/addon_data/<id>/)."""
    base = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    return os.path.join(base, *parts)


def folder_item(label):
    item = xbmcgui.ListItem(label=label, offscreen=True)
    item.setProperty("IsPlayable", "false")
    return item


def programme_item(title, image=None, genres=None):
    """Folder item for a programme."""
    item = folder_item(title)
    if image:
        item.setArt({"thumb": image, "icon": image, "fanart": image})
    tag = item.getVideoInfoTag()
    tag.setMediaType("tvshow")
    tag.setTitle(title)
    if genres:
        tag.setGenres(list(genres))
    return item


def section_item(label, image=None, plot=None):
    """Folder item inside a programme (a season or a tab)."""
    item = folder_item(label)
    if image:
        item.setArt({"thumb": image, "icon": image, "fanart": image})
    if plot:
        item.getVideoInfoTag().setPlot(plot)
    return item


def episode_item(title, image=None, fanart=None, show=None, season=None, plot=None, mediatype="episode",
                 episode=None, duration=None):
    """Playable item for an episode or a stand-alone video in a listing."""
    item = xbmcgui.ListItem(label=title, offscreen=True)
    art = {"thumb": image, "icon": image, "fanart": fanart or image}
    item.setArt({key: value for key, value in art.items() if value})
    tag = item.getVideoInfoTag()
    tag.setMediaType(mediatype)
    tag.setTitle(title)
    if show:
        tag.setTvShowTitle(show)
    if season is not None:
        tag.setSeason(season)
    if plot:
        tag.setPlot(plot)
    if episode is not None:
        tag.setEpisode(episode)
    if duration:
        tag.setDuration(int(duration))
    item.setProperty("IsPlayable", "true")
    return item


def playable_item(url, mime_type, title=None, plot=None, duration=None, image=None, subtitles=None):
    """The resolved item handed to Kodi's player."""
    item = xbmcgui.ListItem(path=url, offscreen=True)
    item.setMimeType(mime_type)
    item.setContentLookup(False)
    if image:
        item.setArt({"thumb": image, "icon": image, "fanart": image})
    tag = item.getVideoInfoTag()
    tag.setMediaType("video")  # an episode or a stand-alone film: the page does not say which
    if title:
        tag.setTitle(title)
    if plot:
        tag.setPlot(plot)
    if duration:
        tag.setDuration(int(duration))
    if subtitles:
        item.setSubtitles(list(subtitles))
    return item


def resolve(handle, item):
    xbmcplugin.setResolvedUrl(handle, True, item)


def resolve_failed(handle):
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))


def action_item(label):
    """An entry that runs an action instead of opening a folder or playing."""
    item = xbmcgui.ListItem(label=label, offscreen=True)
    item.setProperty("IsPlayable", "false")
    return item


def refresh_container():
    xbmc.executebuiltin("Container.Refresh")


def add_items(handle, items):
    """items: iterable of (url, ListItem, is_folder)."""
    xbmcplugin.addDirectoryItems(handle, list(items))


def set_content(handle, content):
    xbmcplugin.setContent(handle, content)


def container_update(url):
    """Navigate the current window to url (adds a history entry)."""
    xbmc.executebuiltin("Container.Update(%s)" % url)


def end_directory(handle, succeeded=True, cache=True):
    xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=cache)
