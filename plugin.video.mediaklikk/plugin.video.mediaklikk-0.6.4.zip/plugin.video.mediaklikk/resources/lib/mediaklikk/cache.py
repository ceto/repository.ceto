"""Small on-disk cache for parsed catalogue data.

Entries are JSON files holding already-parsed data, never raw pages, player
tokens or stream URLs. When a refresh fails, the previous entry is served
even if it is past its lifetime.

Pure Python: no Kodi imports. Any cache problem degrades to a live request.
"""
import hashlib
import json
import os
import time

from mediaklikk.http import MediaklikkError

SCHEMA = 1  # bump when the stored data's shape changes


class Cache(object):
    def __init__(self, directory, clock=time.time):
        self.directory = directory
        self.clock = clock
        self.served_stale = False  # True when the last get() fell back to an expired entry

    def _path(self, key):
        return os.path.join(self.directory, hashlib.sha1(key.encode("utf-8")).hexdigest() + ".json")

    def _read(self, path):
        try:
            with open(path, encoding="utf-8") as fh:
                entry = json.load(fh)
            if entry["schema"] != SCHEMA:
                return None
            return float(entry["stored"]), entry["payload"]
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _write(self, path, payload):
        try:
            if not os.path.isdir(self.directory):
                os.makedirs(self.directory)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"schema": SCHEMA, "stored": self.clock(), "payload": payload}, fh)
            os.replace(tmp, path)
        except OSError:
            pass

    def get(self, key, ttl, loader):
        """Fresh entry, else loader() (stored), else the expired entry if the
        loader fails with a MediaklikkError. Other exceptions propagate."""
        self.served_stale = False
        path = self._path(key)
        entry = self._read(path)
        if entry is not None and 0 <= self.clock() - entry[0] < ttl:
            return entry[1]
        try:
            payload = loader()
        except MediaklikkError:
            if entry is None:
                raise
            self.served_stale = True
            return entry[1]
        self._write(path, payload)
        return payload

    def clear(self):
        try:
            names = os.listdir(self.directory)
        except OSError:
            return
        for name in names:
            if name.endswith(".json") or name.endswith(".tmp"):
                try:
                    os.remove(os.path.join(self.directory, name))
                except OSError:
                    pass
