"""Episode pages: metadata and the player configuration.

See docs/feasibility.md section 6. The token and subtitle paths returned
here are for immediate use only: never cache or log them.

Pure Python: no Kodi imports.
"""
import html
import json
import re

from mediaklikk.catalogue import absolute_url
from mediaklikk.http import ParseError

_TAG = re.compile(r"<[^>]+>")
_META = r'<meta (?:property|name)="%s" content="([^"]*)"'
_LOAD_PLAYER = re.compile(r"loadPlayer\(\s*'[^']*'\s*,\s*(?=\{)")
_TOKEN = re.compile(r'"token"\s*:\s*"([^"]+)"')
_TITLE = re.compile(r'<h1 class="article_title">(.*?)</h1>', re.S)
_LEAD = re.compile(r'<p class="article_lead[^"]*">(.*?)</p>', re.S)
_LENGTH = re.compile(r'data-length="(\d+)"')
_AGE = re.compile(r"""vp-info-adult-content[^>]*>\s*<div class=['"]acl-(\d+)['"]""")
_POST_ID = re.compile(r'data-postid="(\d+)"')
_DATE = re.compile(r"^(\d{4}-\d{2}-\d{2})")
# Tokens are base64 that the page has already percent-encoded.
_TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9%._~+/=-]{16,}$")


def _text(fragment):
    return " ".join(html.unescape(_TAG.sub("", fragment or "")).split())


def _first(pattern, text):
    match = pattern.search(text)
    return match.group(1) if match else None


def _meta(name, page):
    value = _first(re.compile(_META % re.escape(name)), page)
    return html.unescape(value) if value else ""


def _player_setup(page):
    """The object passed to the page's loadPlayer() call, or {}."""
    match = _LOAD_PLAYER.search(page)
    if not match:
        return {}
    try:
        setup, _ = json.JSONDecoder().raw_decode(page, match.end())
    except ValueError:
        return {}
    return setup if isinstance(setup, dict) else {}


def parse_page(page):
    """-> {"id", "title", "description", "image", "published", "duration",
    "age", "token", "subtitle_paths"}. token is None when the page has no
    player (the video is not available). published is the date of the web
    upload, not of the original broadcast; duration is in seconds."""
    if not isinstance(page, str) or not page.strip():
        raise ParseError("episode page is empty")
    setup = _player_setup(page)
    token = setup.get("token") if isinstance(setup.get("token"), str) else _first(_TOKEN, page)
    if token is not None and not _TOKEN_SHAPE.match(token):
        token = None
    paths = setup.get("subtitlePath")
    if isinstance(paths, str):
        paths = [paths]
    paths = [p for p in paths if isinstance(p, str) and p.startswith("/")] if isinstance(paths, list) else []
    minutes = _first(_LENGTH, page)
    title = _text(_first(_TITLE, page)) or _meta("og:title", page) or (setup.get("title") or "")
    return {
        "id": _first(_POST_ID, page),
        "title": " ".join(str(title).split()),
        "description": _meta("og:description", page) or _text(_first(_LEAD, page)),
        "image": absolute_url(_meta("og:image", page)),
        "published": _first(_DATE, _meta("article:published_time", page)),
        "duration": int(minutes) * 60 if minutes else None,
        "age": _first(_AGE, page),
        "token": token,
        "subtitle_paths": paths,
    }
