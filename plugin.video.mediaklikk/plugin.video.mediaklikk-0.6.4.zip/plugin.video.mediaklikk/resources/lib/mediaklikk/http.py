"""Small HTTP client on top of urllib (no third-party packages).

Pure Python: no Kodi imports, so it is testable on the host.
"""
import gzip
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

DEFAULT_TIMEOUT = 15


class MediaklikkError(Exception):
    """Base class for all errors raised by this add-on's library."""


class NetworkError(MediaklikkError):
    """DNS failure, refused connection, TLS problem or timeout."""


class HttpError(MediaklikkError):
    def __init__(self, status):
        MediaklikkError.__init__(self, "HTTP %d" % status)
        self.status = status


class ParseError(MediaklikkError):
    """The response did not have the structure we rely on."""


def loggable(url):
    """Host and path only: queries can carry tokens or the client IP."""
    try:
        parts = urlsplit(url)
        return "%s://%s%s" % (parts.scheme, parts.hostname or "", parts.path)
    except ValueError:
        return "<invalid url>"


class HttpClient(object):
    def __init__(self, user_agent, timeout=DEFAULT_TIMEOUT, opener=urlopen, logger=None):
        self.user_agent = user_agent
        self.timeout = timeout
        self._open = opener
        self._log = logger or (lambda msg: None)

    def fetch(self, url, data=None, headers=None):
        """GET (or POST when data is given) and return the body as text.
        data: bytes for the request body."""
        hdrs = {"User-Agent": self.user_agent, "Accept-Encoding": "gzip"}
        hdrs.update(headers or {})
        method = "POST" if data is not None else "GET"
        req = Request(url, data=data, headers=hdrs, method=method)
        try:
            resp = self._open(req, timeout=self.timeout)
            status = getattr(resp, "status", None) or resp.getcode()
            raw = resp.read()
            encoding = resp.headers.get("Content-Encoding", "") if resp.headers else ""
        except HTTPError as exc:
            self._log("%s %s -> %d" % (method, loggable(url), exc.code))
            exc.close()
            raise HttpError(exc.code)
        except (URLError, socket.timeout, ConnectionError, OSError) as exc:
            self._log("%s %s -> network error (%s)" % (method, loggable(url), type(exc).__name__))
            raise NetworkError(type(exc).__name__)
        self._log("%s %s -> %d" % (method, loggable(url), status))
        if status != 200:
            raise HttpError(status)
        try:
            if encoding.lower() == "gzip":
                raw = gzip.decompress(raw)
            return raw.decode("utf-8")
        except (OSError, EOFError, UnicodeDecodeError):
            raise ParseError("undecodable response body")
