"""Search history: the user's recent queries, newest first.

A small JSON file in the add-on profile. Pure Python: no Kodi imports.
"""
import json
import os

from mediaklikk.catalogue import fold

LIMIT = 12


class History(object):
    def __init__(self, path, limit=LIMIT):
        self.path = path
        self.limit = limit

    def entries(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return []
        if not isinstance(data, list):
            return []
        return [entry for entry in data if isinstance(entry, str) and entry.strip()][:self.limit]

    def _save(self, entries):
        try:
            directory = os.path.dirname(self.path)
            if not os.path.isdir(directory):
                os.makedirs(directory)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(entries, fh, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass  # history is a convenience: never fail a search over it

    def add(self, query):
        """Put query first; an earlier entry that differs only in case or accents is replaced."""
        query = " ".join(query.split())
        if not query:
            return
        kept = [entry for entry in self.entries() if fold(entry) != fold(query)]
        self._save(([query] + kept)[:self.limit])

    def clear(self):
        try:
            os.remove(self.path)
        except OSError:
            pass
