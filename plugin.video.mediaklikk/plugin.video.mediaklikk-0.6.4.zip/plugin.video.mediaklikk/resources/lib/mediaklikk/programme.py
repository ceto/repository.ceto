"""Programme pages: seasons, tabs and the video items they list.

See docs/feasibility.md sections 5 and 14.4. A programme page carries the
season selector, the tab list and the items of the active tab; other tabs
come from the site's render_widget request.

Pure Python: no Kodi imports.
"""
import html
import json
import re
from urllib.parse import urlencode, urlsplit

from mediaklikk.catalogue import absolute_url
from mediaklikk.http import ParseError

WIDGET_URL = "https://mediaklikk.hu/wp-content/plugins/hms-global-widgets/interfaces/ajaxHandler.php"

_SITE_HOSTS = ("mediaklikk.hu", "www.mediaklikk.hu")
_TAG = re.compile(r"<[^>]+>")
_MARKER = "program_display"  # present on every programme page that uses the programme widget

_SHOW_ID = re.compile(r"showId\s*:\s*(\d+)")
_POST_ID = re.compile(r"\bpostid-(\d+)")
_TITLE = re.compile(r'<h2 class="program_title">(.*?)</h2>', re.S)
_DESCRIPTION = re.compile(r'<div class="program_description[^"]*">(.*?)</div>', re.S)
_OG = r'<meta property="og:%s" content="([^"]*)"'
_SEASON = re.compile(
    r"""<div class=['"]season-select-option[^'"]*['"]\s+data-value=['"](\d+)['"]\s+data-number=['"]([^'"]*)['"][^>]*>(.*?)</div>""",
    re.S)
_ACTIVE_SEASON = re.compile(r"""class=['"]season-select-default['"]\s+data-value=['"](\d+)['"]""")
_TAB = re.compile(r'<div class="program_tab(?![\w-])([^"]*)"([^>]*)>\s*<div class="tab_title">(.*?)</div>', re.S)
_TAB_CONTENT = re.compile(r"""<div id=['"]tab_content_([^'"]+)['"]""")
_CARD_SPLIT = re.compile(r'<div class="cikk(?![\w-])')
_CARD_CLASSES = re.compile(r'^([^"]*)"')
_HREF = re.compile(r'<a\s+href="([^"]+)"')
_IMAGE = re.compile(r'data-src="([^"]+)"')
_CLIP_ID = re.compile(r'data-video-clip-id="(\d+)"')
_CARD_TITLE = re.compile(r"<h1[^>]*>(.*?)</h1>", re.S)


def _attr(name, text):
    match = re.search(r'%s="([^"]*)"' % re.escape(name), text)
    return match.group(1) if match else ""


def _text(fragment):
    return " ".join(html.unescape(_TAG.sub("", fragment or "")).split())


def _first(pattern, text):
    match = pattern.search(text)
    return match.group(1) if match else None


def episode_url(url):
    """https URL of a page on mediaklikk.hu, or None."""
    url = absolute_url(html.unescape(url or ""))
    if url is None:
        return None
    try:
        host = urlsplit(url).hostname
    except ValueError:
        return None
    return url if host in _SITE_HOSTS else None


def parse_items(fragment):
    """Video items of a grid: [{"id", "title", "url", "image"}], as served.
    Non-video cards, cards without a title or link, and repeats are skipped."""
    items = []
    seen = set()
    for card in _CARD_SPLIT.split(fragment or "")[1:]:
        classes = (_first(_CARD_CLASSES, card) or "").split()
        url = episode_url(_first(_HREF, card))
        title = _text(_first(_CARD_TITLE, card))
        if not url or not title:
            continue
        if "video" not in classes and "/video/" not in url:
            continue
        clip_id = _first(_CLIP_ID, card)
        key = clip_id or url
        if key in seen:
            continue
        seen.add(key)
        items.append({"id": clip_id, "title": title, "url": url,
                      "image": absolute_url(html.unescape(_first(_IMAGE, card) or ""))})
    return items


def parse_page(page):
    """-> {"id", "title", "description", "image", "seasons", "active_season",
    "tabs", "inline"} from a programme page.

    seasons: [{"id", "number", "label"}] as on the site (newest first)
    tabs: [{"id", "content_type", "content_id", "season_id", "title"}]
    inline: {tab id: items} for tabs whose content is in the page"""
    if not isinstance(page, str) or _MARKER not in page:
        raise ParseError("not a programme page")
    programme_id = _first(_SHOW_ID, page) or _first(_POST_ID, page)
    seasons = []
    for season_id, number, label in _SEASON.findall(page):
        if all(season_id != s["id"] for s in seasons):
            seasons.append({"id": season_id, "number": number.strip(), "label": _text(label)})
    tabs = []
    for _, attributes, title in _TAB.findall(page):
        tab_id = _attr("data-tab", attributes)
        if not tab_id or any(tab_id == t["id"] for t in tabs):
            continue
        tabs.append({"id": tab_id,
                     "content_type": _attr("data-content-type", attributes),
                     "content_id": _attr("data-content-id", attributes),
                     "season_id": _attr("data-season-id", attributes),
                     "title": _text(title)})
    inline = {}
    tab_ids = set(tab["id"] for tab in tabs)
    markers = list(_TAB_CONTENT.finditer(page))  # also matches template strings in the page's script
    for index, marker in enumerate(markers):
        if marker.group(1) not in tab_ids:
            continue
        end = markers[index + 1].start() if index + 1 < len(markers) else len(page)
        inline[marker.group(1)] = parse_items(page[marker.end():end])
    return {
        "id": programme_id,
        "title": _text(_first(_TITLE, page)) or _text(_first(re.compile(_OG % "title"), page)),
        "description": _text(_first(_DESCRIPTION, page)),
        "image": absolute_url(html.unescape(_first(re.compile(_OG % "image"), page) or "")),
        "seasons": seasons,
        "active_season": _first(_ACTIVE_SEASON, page),
        "tabs": tabs,
        "inline": inline,
    }


def widget_body(programme_id, tab):
    """Form body of the site's render_widget request for a tab."""
    return urlencode([
        ("action", "render_widget"),
        ("contentId", tab["content_id"]),
        ("contentType", tab["content_type"]),
        ("tabId", tab["id"]),
        ("showId", programme_id),
        ("loop", "false"),
        ("seasonId", tab["season_id"]),
    ]).encode("ascii")


def parse_widget(text):
    """Items from a render_widget response. An empty widget is a normal answer."""
    try:
        payload = json.loads(text)
    except (ValueError, TypeError):
        raise ParseError("widget response is not JSON")
    if not isinstance(payload, dict) or payload.get("success") is not True:
        raise ParseError("widget request was not successful")
    data = payload.get("data")
    fragment = data.get("widget_html") if isinstance(data, dict) else None
    if not isinstance(fragment, str):
        raise ParseError("widget response has no markup")
    return parse_items(fragment)


def season_page_url(programme_url, season_number):
    """The programme page rendered for one season (feasibility 14.4)."""
    return "%s?%s" % (programme_url, urlencode([("evad", season_number)]))


def season_order(seasons):
    """Seasons by number, first season first; unnumbered ones keep their place at the end."""
    def key(indexed):
        index, season = indexed
        return (0, int(season["number"]), index) if season["number"].isdigit() else (1, 0, index)
    return [season for _, season in sorted(enumerate(seasons), key=key)]
