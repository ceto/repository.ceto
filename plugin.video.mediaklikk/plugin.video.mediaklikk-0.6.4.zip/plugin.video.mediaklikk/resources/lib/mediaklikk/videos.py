"""Latest videos of a genre, including stand-alone videos (films) that
belong to no programme.

See docs/feasibility.md sections 5.5 and 14.3: a genre page names a numeric
category id, and the site's own pager endpoint returns that genre's posts
as JSON, newest first.

Pure Python: no Kodi imports.
"""
import html
import json
import re
from urllib.parse import urlencode

from mediaklikk.catalogue import absolute_url
from mediaklikk.http import ParseError
from mediaklikk.programme import episode_url

GENRE_PAGE = "https://mediaklikk.hu/mufajkategoria/%s"
FEED_URL = ("https://mediaklikk.hu/wp-content/plugins/hms-global-widgets/widgets"
            "/categoryAndTagListPage/ajax_loadmore.php")
PAGE_SIZE = 50
FILM = "film"

_SLUG = re.compile(r"^[a-z0-9-]+$")
_CATEGORY = re.compile(r"category_id\s*=\s*'(\d+)'")
_TAX = re.compile(r"tax_type\s*=\s*'(\w+)'")
_TAG = re.compile(r"<[^>]+>")


def valid_slug(slug):
    return isinstance(slug, str) and bool(_SLUG.match(slug))


def genre_page_url(slug):
    if not valid_slug(slug):
        raise ValueError("not a genre slug")
    return GENRE_PAGE % slug


def parse_genre_page(page):
    """The genre's numeric category id from its page."""
    if not isinstance(page, str):
        raise ParseError("genre page is not text")
    category = _CATEGORY.search(page)
    tax = _TAX.search(page)
    if not category or not tax or tax.group(1) != "mufaj_category":
        raise ParseError("genre page has no genre category id")
    return category.group(1)


def feed_url(category_id, page=1, page_size=PAGE_SIZE):
    return FEED_URL + "?" + urlencode([
        ("cat_id", category_id), ("post_type", '["video"]'), ("blog_id", 0), ("page_number", page),
        ("is_tag", 0), ("is_tax", 1), ("elements_num", page_size), ("tax_type", "mufaj_category")])


def _text(value):
    return " ".join(html.unescape(_TAG.sub("", value)).split()) if isinstance(value, str) else ""


def parse_feed(text):
    """[{"id", "title", "url", "image", "description"}] in the order served
    (newest first). An empty list is a normal answer (past the last page)."""
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        raise ParseError("video list is not JSON")
    if not isinstance(data, list):
        raise ParseError("video list is not a list")
    items = []
    seen = set()
    for entry in data:
        if not isinstance(entry, dict) or entry.get("post_type") != "video":
            continue
        url = episode_url(entry.get("link") if isinstance(entry.get("link"), str) else None)
        title = _text(entry.get("title"))
        if not url or not title or url in seen:
            continue
        seen.add(url)
        post_id = entry.get("ID")
        items.append({
            "id": str(post_id) if isinstance(post_id, (int, str)) and str(post_id).isdigit() else None,
            "title": title,
            "url": url,
            "image": absolute_url(entry.get("image")),
            "description": _text(entry.get("lead")),
        })
    return items
