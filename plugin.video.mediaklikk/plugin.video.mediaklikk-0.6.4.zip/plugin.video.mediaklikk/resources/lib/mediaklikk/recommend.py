"""Episode numbers and descriptions from the site's side recommender.

See docs/feasibility.md sections 14.2 and 17. For a video id the endpoint
returns a window of neighbouring episodes of the same programme, each with
an editorial episode number. That number is the only reliable ordering for
programmes without seasons, whose pages list videos in upload order.

The response also carries player tokens; they are dropped here and must
never reach the cache.

Pure Python: no Kodi imports.
"""
import html
import json
import re

from mediaklikk.catalogue import fold
from mediaklikk.http import ParseError

URL = "https://mediaklikk.hu/wp-content/plugins/hms-tri-widgets/interfaces/vod-recommend.php"
HEADERS = {"Content-Type": "application/json"}
MAX_PROBES = 4
FIRST_EPISODES = 2  # a list whose lowest number is above this is not treated as a complete run

_TAG = re.compile(r"<[^>]+>")
_ROMAN = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100}
_TITLE_NUMBERS = (
    re.compile(r"\(\s*\d+\s*/\s*(\d+)\s*\.?\s*\)"),          # (14/10)
    re.compile(r"\b(\d+)\.\s*rész", re.I),                   # 3. rész
    re.compile(r"\b([IVXLC]+)\.(?:\s*-\s*[IVXLC]+\.)?\s*rész"),  # XIII. rész, I.- II. rész
)


def body(video_id):
    return json.dumps({"id": int(video_id), "type": "ByEpisode", "excluded_ids": []}).encode("ascii")


def _number(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().isdigit():
        return int(value.strip())
    return None


def _text(value):
    return " ".join(html.unescape(_TAG.sub("", value)).split()) if isinstance(value, str) else ""


def parse(text):
    """{video id: {"episode", "season", "description", "duration"}} for the
    episodes in a response. Nothing else from the response is kept."""
    try:
        payload = json.loads(text)
    except (ValueError, TypeError):
        raise ParseError("recommender response is not JSON")
    try:
        entries = payload["Results"]["ByEpisode"]["Items"]
    except (KeyError, TypeError):
        raise ParseError("recommender response has no episode list")
    if isinstance(entries, dict):
        entries = list(entries.values())
    if not isinstance(entries, list):
        raise ParseError("recommender episode list has an unknown shape")
    details = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        video_id = _number(entry.get("Id"))
        if video_id is None:
            continue
        season = entry.get("Season")
        details[str(video_id)] = {
            "episode": _number(entry.get("EpisodeNumber")),
            "season": _number(season.get("Number")) if isinstance(season, dict) else None,
            "description": _text(entry.get("Description")) or _text(entry.get("Lead")),
            "duration": _number(entry.get("Length")),
        }
    return details


def collect(fetch, video_ids, max_probes=MAX_PROBES):
    """Details for as many of video_ids as a few requests give.
    fetch(video_id) -> response text. Each request covers a window of
    neighbouring episodes, so a handful usually covers a whole list."""
    wanted = [vid for vid in video_ids if vid and str(vid).isdigit()]
    details = {}
    probed = set()
    for _ in range(max_probes):
        target = next((vid for vid in wanted if vid not in details and vid not in probed), None)
        if target is None:
            break
        probed.add(target)
        details.update(parse(fetch(target)))
    return {vid: details[vid] for vid in wanted if vid in details}


def _roman(text):
    total = 0
    for char, following in zip(text, text[1:] + " "):
        value = _ROMAN[char]
        total += -value if _ROMAN.get(following, 0) > value else value
    return total


def title_number(title):
    """A part number written in the title, or None."""
    for index, pattern in enumerate(_TITLE_NUMBERS):
        match = pattern.search(title)
        if match:
            return _roman(match.group(1)) if index == 2 else int(match.group(1))
    return None


def order(items, details):
    """items in episode order, each copied with "episode", "description" and
    "duration" where known.

    Numbers come from the recommender. An item it does not know gets the
    number of an identically titled item (a repeated upload), or else the
    number in its own title when no other item holds that number. Items
    still without a number go last, in their served order.

    The served order (newest upload first) is kept when the numbers cannot
    be trusted as an order: fewer than half of the items are numbered, or
    differently titled items share a number. It is also kept when the
    numbers do not start at the beginning: the page then shows the latest
    part of a longer run, where newest first is the useful order. "The
    beginning" allows for a missing first episode (seen on Tüskevár)."""
    enriched = []
    for item in items:
        known = details.get(item["id"]) or {}
        copy = dict(item, episode=known.get("episode"),
                    description=known.get("description") or "", duration=known.get("duration"))
        enriched.append(copy)
    numbered = [item for item in enriched if item["episode"] is not None]
    by_title = {}
    for item in numbered:
        by_title.setdefault(fold(item["title"]), item["episode"])
    owners = {}
    for item in numbered:
        owners.setdefault(item["episode"], set()).add(fold(item["title"]))
    clashing = any(len(titles) > 1 for titles in owners.values())
    if not enriched or len(numbered) * 2 < len(enriched) or clashing:
        for item in enriched:
            item["episode"] = None  # not usable as an order, so not shown as numbering either
        return enriched
    taken = set(item["episode"] for item in numbered)
    keys = {}
    for index, item in enumerate(enriched):
        number = item["episode"]
        inferred = number is None
        if inferred:
            number = by_title.get(fold(item["title"]))
            if number is None:
                guess = title_number(item["title"])
                if guess is not None and guess not in taken:
                    number = guess
                    taken.add(guess)
            item["episode"] = number
        # an item whose number was inferred follows the one the recommender numbered
        keys[id(item)] = (0, number, inferred, index) if number is not None else (1, 0, False, index)
    if min(item["episode"] for item in enriched if item["episode"] is not None) > FIRST_EPISODES:
        return enriched
    return sorted(enriched, key=lambda item: keys[id(item)])
