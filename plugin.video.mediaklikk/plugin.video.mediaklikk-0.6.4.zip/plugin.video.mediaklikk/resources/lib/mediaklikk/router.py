"""Maps plugin:// URLs to handlers and builds Kodi listings."""
from urllib.parse import parse_qsl, urlencode, urlsplit

from mediaklikk import cache, catalogue, episode, history, http, kodiutil, playback, programme, recommend, videos

STR_ALL = 30001
STR_GENRES = 30002
STR_SEARCH = 30003
STR_OTHER = 30004
STR_FILMS = 30005
STR_LATEST_VIDEOS = 30006
STR_NEXT_PAGE = 30007
STR_COMING_SOON = 30010
STR_ERROR = 30011
STR_NETWORK_ERROR = 30012
STR_SERVER_ERROR = 30013
STR_NO_RESULTS = 30014
STR_SEARCH_HEADING = 30015
STR_GENRES_UNAVAILABLE = 30016
STR_CACHE_CLEARED = 30017
STR_SITE_CHANGED = 30018
STR_NO_VIDEOS = 30019
STR_UNAVAILABLE = 30020
STR_UNSUPPORTED = 30021
STR_REFUSED = 30022
STR_NO_VIDEOS_HERE = 30023
STR_NEW_SEARCH = 30024
STR_CLEAR_HISTORY = 30025

CATALOGUE_TTL = 24 * 60 * 60
PROGRAMME_TTL = 60 * 60
VIDEO_LIST_TTL = 30 * 60
_FORM = {"Content-Type": "application/x-www-form-urlencoded"}

# Actions run with RunPlugin (no directory to close).
NON_DIRECTORY_ACTIONS = ("clear_cache", "search_new", "search_clear")


class Request(object):
    def __init__(self, base_url, handle, params):
        self.base_url = base_url
        self.handle = handle
        self.params = params

    def url(self, **params):
        """plugin:// URL for a route; values are percent-encoded as UTF-8."""
        query = urlencode([(k, v) for k, v in sorted(params.items()) if v not in (None, "")])
        return self.base_url + ("?" + query if query else "")


class Services(object):
    """What handlers need besides the request: HTTP client and cache."""

    def __init__(self, client, store, searches):
        self.client = client
        self.cache = store
        self.history = searches

    def catalogue(self):
        """The catalogue, radio programmes removed when the setting says so."""
        data = self.cache.get("catalogue", CATALOGUE_TTL, lambda: catalogue.load(self.client))
        if self.cache.served_stale:
            kodiutil.log("catalogue refresh failed, using the stored copy")
        tv_only = kodiutil.setting_bool("tv_only", True)
        return dict(data, programmes=catalogue.visible(data["programmes"], tv_only))

    def genre_videos(self, slug, page):
        """One page of a genre's latest videos."""
        category = self.cache.get("genre-id:" + slug, CATALOGUE_TTL,
                                  lambda: videos.parse_genre_page(self.client.fetch(videos.genre_page_url(slug))))
        return self.cache.get("genre-videos:%s:%d" % (slug, page), VIDEO_LIST_TTL,
                              lambda: videos.parse_feed(self.client.fetch(videos.feed_url(category, page))))

    def programme(self, url):
        """Parsed programme page for a normalised programme URL."""
        return self.cache.get("programme:" + url, PROGRAMME_TTL,
                              lambda: programme.parse_page(self.client.fetch(url)))

    def tab_items(self, url, page, tab):
        """Items of one tab: from the page when inline, else the site's widget request."""
        if tab["id"] in page["inline"]:
            return page["inline"][tab["id"]]
        if not page["id"]:
            raise http.ParseError("programme page has no programme id")

        def load():
            body = programme.widget_body(page["id"], tab)
            return programme.parse_widget(self.client.fetch(programme.WIDGET_URL, data=body, headers=_FORM))
        return self.cache.get("tab:%s:%s" % (url, tab["id"]), PROGRAMME_TTL, load)

    def ordered_tab_items(self, url, page, tab):
        """A tab's items in episode order with descriptions, where the site's
        recommender knows them; otherwise as served. The extra requests are an
        improvement only: when they fail, the plain list is shown."""
        items = self.tab_items(url, page, tab)
        if len(items) < 2:
            return recommend.order(items, {})

        def load():
            def fetch(video_id):
                return self.client.fetch(recommend.URL, data=recommend.body(video_id), headers=recommend.HEADERS)
            return recommend.collect(fetch, [item["id"] for item in items])
        try:
            details = self.cache.get("episodes:%s:%s" % (url, tab["id"]), PROGRAMME_TTL, load)
        except http.MediaklikkError as exc:
            kodiutil.log("episode numbers unavailable (%s), keeping the site's order" % type(exc).__name__)
            details = {}
        return recommend.order(items, details)

    def season_items(self, url, page, season):
        """Items of a season, first episode first. Falls back to the season's
        own page when the widget request fails or returns nothing."""
        tabs = [tab for tab in page["tabs"] if tab["season_id"] == season["id"]]
        items = []
        try:
            for tab in tabs:
                items.extend(reversed(self.tab_items(url, page, tab)))
        except http.MediaklikkError as exc:
            kodiutil.log("season widget failed (%s), trying the season page" % type(exc).__name__)
            items = []
        if not items and season["number"]:
            def load():
                season_page = programme.parse_page(
                    self.client.fetch(programme.season_page_url(url, season["number"])))
                found = []
                for tab in season_page["tabs"]:
                    if tab["season_id"] == season["id"]:
                        found.extend(reversed(season_page["inline"].get(tab["id"], [])))
                return found
            items = self.cache.get("season:%s:%s" % (url, season["id"]), PROGRAMME_TTL, load)
        unique, seen = [], set()
        for item in items:
            key = item["id"] or item["url"]
            if key not in seen:
                seen.add(key)
                unique.append(item)
        return unique


def make_services():
    user_agent = "Kodi %s/%s" % (kodiutil.ADDON_ID, kodiutil.ADDON_VERSION)
    client = http.HttpClient(user_agent, logger=kodiutil.log)
    return Services(client, cache.Cache(kodiutil.profile_path("cache")),
                    history.History(kodiutil.profile_path("search_history.json")))


def parse_argv(argv):
    """argv as Kodi passes it: [base url, handle, '?query']."""
    base_url = argv[0]
    handle = int(argv[1]) if len(argv) > 1 else -1
    query = argv[2] if len(argv) > 2 else ""
    if not query:
        query = urlsplit(base_url).query
    params = dict(parse_qsl(query.lstrip("?"), keep_blank_values=False))
    return Request(base_url.split("?")[0], handle, params)


def show_root(req, services):
    entries = ((STR_ALL, {"action": "all"}), (STR_GENRES, {"action": "genres"}),
               (STR_FILMS, {"action": "videos", "slug": videos.FILM}), (STR_SEARCH, {"action": "search"}))
    kodiutil.add_items(req.handle, [
        (req.url(**query), kodiutil.folder_item(kodiutil.localize(label)), True)
        for label, query in entries])
    kodiutil.end_directory(req.handle)


def _list_programmes(req, programmes, genres, cache_listing=True, videos_slug=None):
    items = []
    if videos_slug:
        latest = kodiutil.folder_item(kodiutil.localize(STR_LATEST_VIDEOS))
        items.append((req.url(action="videos", slug=videos_slug), latest, True))
    for programme in programmes:
        names = [genres[slug] for slug in programme["genres"] if slug in genres]
        item = kodiutil.programme_item(programme["title"], programme["image"], names)
        items.append((req.url(action="programme", url=programme["url"]), item, True))
    kodiutil.add_items(req.handle, items)
    kodiutil.set_content(req.handle, "tvshows")
    kodiutil.end_directory(req.handle, cache=cache_listing)


def show_all(req, services):
    data = services.catalogue()
    _list_programmes(req, catalogue.by_title(data["programmes"]), data["genres"])


def show_genres(req, services):
    data = services.catalogue()
    rows = catalogue.genre_counts(data["programmes"], data["genres"])
    if data["source"] != catalogue.SOURCE_PAGE or not rows:
        # The fallback source has no genres: say so instead of showing an empty folder.
        kodiutil.notify(kodiutil.localize(STR_GENRES_UNAVAILABLE))
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        return
    items = []
    for slug, name, count in rows:
        label = "%s (%d)" % (name or kodiutil.localize(STR_OTHER), count)
        items.append((req.url(action="genre", slug=slug or "-"), kodiutil.folder_item(label), True))
    kodiutil.add_items(req.handle, items)
    kodiutil.end_directory(req.handle)


def show_genre(req, services):
    slug = req.params.get("slug", "")
    data = services.catalogue()
    programmes = catalogue.in_genre(data["programmes"], catalogue.NO_GENRE if slug == "-" else slug)
    if not programmes:
        kodiutil.notify(kodiutil.localize(STR_NO_RESULTS))
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        return
    # A genre known to the site also has a list of its latest videos, which is
    # where stand-alone videos (films) are found.
    videos_slug = slug if slug in data["genres"] and videos.valid_slug(slug) else None
    _list_programmes(req, catalogue.by_title(programmes), data["genres"], videos_slug=videos_slug)


def show_videos(req, services):
    slug = req.params.get("slug", "")
    if not videos.valid_slug(slug):
        raise ValueError("not a genre slug")
    try:
        page = max(1, int(req.params.get("page", 1)))
    except ValueError:
        page = 1
    items = services.genre_videos(slug, page)
    if not items:
        kodiutil.notify(kodiutil.localize(STR_NO_RESULTS if page > 1 else STR_NO_VIDEOS_HERE))
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        return
    entries = []
    for item in items:
        list_item = kodiutil.episode_item(item["title"], item["image"], plot=item["description"], mediatype="video")
        entries.append((req.url(action="play", url=item["url"]), list_item, False))
    if len(items) >= videos.PAGE_SIZE:
        more = kodiutil.folder_item(kodiutil.localize(STR_NEXT_PAGE))
        entries.append((req.url(action="videos", slug=slug, page=page + 1), more, True))
    kodiutil.add_items(req.handle, entries)
    kodiutil.set_content(req.handle, "videos")
    kodiutil.end_directory(req.handle)


def show_search(req, services):
    query = req.params.get("q")
    if not query:
        # The search folder: a "new search" action and the recent queries. The
        # keyboard is opened by the action, not while this folder loads: asking
        # here and then redirecting races with Kodi's own directory update
        # (the redirect is dropped), and re-asks whenever the user comes back.
        entries = [(req.url(action="search_new"),
                    kodiutil.action_item(kodiutil.localize(STR_NEW_SEARCH)), False)]
        recent = services.history.entries()
        for entry in recent:
            entries.append((req.url(action="search", q=entry), kodiutil.folder_item(entry), True))
        if recent:
            entries.append((req.url(action="search_clear"),
                            kodiutil.action_item(kodiutil.localize(STR_CLEAR_HISTORY)), False))
        kodiutil.add_items(req.handle, entries)
        kodiutil.end_directory(req.handle, cache=False)
        return
    data = services.catalogue()
    found = catalogue.search(data["programmes"], query)
    if not found:
        kodiutil.notify(kodiutil.localize(STR_NO_RESULTS))
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        return
    _list_programmes(req, found, data["genres"], cache_listing=False)


def search_new(req, services):
    query = kodiutil.keyboard(kodiutil.localize(STR_SEARCH_HEADING))
    if not query:
        return
    services.history.add(query)
    kodiutil.container_update(req.url(action="search", q=query))


def search_clear(req, services):
    services.history.clear()
    kodiutil.refresh_container()


def _programme_request(req, services):
    url = catalogue.programme_url(req.params.get("url"))
    if url is None:
        raise ValueError("not a programme URL")
    return url, services.programme(url)


def _no_videos(req):
    kodiutil.notify(kodiutil.localize(STR_NO_VIDEOS))
    kodiutil.end_directory(req.handle, succeeded=False, cache=False)


def _list_episodes(req, page, items, season=None):
    if not items:
        _no_videos(req)
        return
    number = int(season["number"]) if season and season["number"].isdigit() else None
    entries = []
    for item in items:
        list_item = kodiutil.episode_item(item["title"], item["image"], page["image"], page["title"], number,
                                          plot=item.get("description"), episode=item.get("episode"),
                                          duration=item.get("duration"))
        entries.append((req.url(action="play", url=item["url"]), list_item, False))
    kodiutil.add_items(req.handle, entries)
    kodiutil.set_content(req.handle, "episodes")
    kodiutil.end_directory(req.handle)


def show_programme(req, services):
    url, page = _programme_request(req, services)
    seasons = programme.season_order(page["seasons"])
    plain_tabs = [tab for tab in page["tabs"] if not tab["season_id"]]
    if not seasons and len(plain_tabs) == 1:
        _list_episodes(req, page, services.ordered_tab_items(url, page, plain_tabs[0]))
        return
    if not seasons and not plain_tabs:
        _no_videos(req)
        return
    entries = []
    for season in seasons:
        label = season["label"] or season["number"] or season["id"]
        item = kodiutil.section_item(label, page["image"], page["description"])
        entries.append((req.url(action="season", url=url, season=season["id"]), item, True))
    for tab in plain_tabs:
        item = kodiutil.section_item(tab["title"] or tab["id"], page["image"], page["description"])
        entries.append((req.url(action="tab", url=url, tab=tab["id"]), item, True))
    kodiutil.add_items(req.handle, entries)
    kodiutil.set_content(req.handle, "seasons" if seasons else "videos")
    kodiutil.end_directory(req.handle)


def show_season(req, services):
    url, page = _programme_request(req, services)
    season = next((s for s in page["seasons"] if s["id"] == req.params.get("season")), None)
    if season is None:
        _no_videos(req)
        return
    _list_episodes(req, page, services.season_items(url, page, season), season)


def show_tab(req, services):
    url, page = _programme_request(req, services)
    tab = next((t for t in page["tabs"] if t["id"] == req.params.get("tab")), None)
    if tab is None:
        _no_videos(req)
        return
    _list_episodes(req, page, services.ordered_tab_items(url, page, tab))


def play(req, services):
    url = programme.episode_url(req.params.get("url"))
    if url is None:
        raise ValueError("not an episode URL")
    if "?" not in url and not url.endswith("/"):
        url += "/"  # the site redirects slash-less episode URLs through plain http
    # Fetched fresh every time: the token and the stream URL must not be stored.
    page = episode.parse_page(services.client.fetch(url))
    if not page["token"]:
        raise playback.Unavailable("no player on the episode page")
    stream = playback.resolve(services.client, page["token"], page["subtitle_paths"], referer=url, log=kodiutil.log)
    kodiutil.log("resolved episode %s: hls, %d subtitle track(s)" % (page["id"], len(stream["subtitles"])))
    item = kodiutil.playable_item(stream["url"], stream["mime"], page["title"], page["description"],
                                  page["duration"], page["image"], stream["subtitles"])
    kodiutil.resolve(req.handle, item)


def clear_cache(req, services):
    services.cache.clear()
    kodiutil.notify(kodiutil.localize(STR_CACHE_CLEARED))


HANDLERS = {
    "all": show_all,
    "genres": show_genres,
    "genre": show_genre,
    "videos": show_videos,
    "search": show_search,
    "search_new": search_new,
    "search_clear": search_clear,
    "programme": show_programme,
    "season": show_season,
    "tab": show_tab,
    "play": play,
    "clear_cache": clear_cache,
}


def run(argv, services_factory=make_services):
    req = parse_argv(argv)
    action = req.params.get("action")
    kodiutil.log("route action=%s" % (action or "root"))
    handler = show_root if not action else HANDLERS.get(action)
    if handler is None:
        kodiutil.log_error("unknown action %r" % action)
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        return
    try:
        handler(req, services_factory())
        return
    except (playback.DrmProtected, playback.Unsupported) as exc:
        kodiutil.log_error("cannot play: %s (%s)" % (type(exc).__name__, exc))
        message = kodiutil.localize(STR_UNSUPPORTED)
    except playback.Unavailable as exc:
        kodiutil.log_error("video unavailable: %s" % exc)
        message = kodiutil.localize(STR_UNAVAILABLE)
    except playback.PlayerRefused as exc:
        kodiutil.log_error("player refused the request: %s" % exc.code)
        message = kodiutil.localize(STR_REFUSED)
    except http.NetworkError as exc:
        kodiutil.log_error("network error in %r: %s" % (action, exc))
        message = kodiutil.localize(STR_NETWORK_ERROR)
    except http.HttpError as exc:
        kodiutil.log_error("HTTP error in %r: %s" % (action, exc.status))
        message = kodiutil.localize(STR_SERVER_ERROR) % exc.status
    except http.ParseError as exc:
        kodiutil.log_error("unexpected response in %r: %s" % (action, exc))
        message = kodiutil.localize(STR_SITE_CHANGED)
    except Exception as exc:  # last-resort guard: never crash into Kodi's UI
        kodiutil.log_error("unhandled %s in action %r: %s" % (type(exc).__name__, action, exc))
        message = kodiutil.localize(STR_ERROR)
    kodiutil.notify_error(message)
    if action == "play":
        kodiutil.resolve_failed(req.handle)
    elif action not in NON_DIRECTORY_ACTIONS:
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
