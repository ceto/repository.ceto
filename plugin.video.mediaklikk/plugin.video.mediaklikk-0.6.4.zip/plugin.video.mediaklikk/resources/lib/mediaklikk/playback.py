"""Turning an episode's player token into a stream Kodi can play.

See docs/feasibility.md sections 7, 8 and 15. The primary resolver is the
player's own get_video_url.php (JSON with explicit DRM fields). player.php is
used for the subtitle track and as a fallback.

Nothing here is cached or logged: stream and subtitle URLs are signed and
carry the client's IP address.

Pure Python: no Kodi imports.
"""
import json
import re
from urllib.parse import quote, urlsplit

from mediaklikk.catalogue import absolute_url
from mediaklikk.http import MediaklikkError, ParseError

VIDEO_URL = "https://player.mediaklikk.hu/playernew/core/player/get_video_url.php"
PLAYER_URL = "https://player.mediaklikk.hu/playernew/player.php"
HLS_MIME = "application/vnd.apple.mpegurl"

_DRM_FIELDS = ("drmKey", "drmCertURL", "drmProxyURL")
_SETUP = re.compile(r"\.setup\(\s*(?=\{)")
_ERROR = re.compile(r"<!--\s*[^<>]*?\s-\s([A-Z][A-Z_]+)\s*-->")


class PlaybackError(MediaklikkError):
    """The stream cannot be played; subclasses say why."""


class Unavailable(PlaybackError):
    """The site has no playable video for this item."""


class DrmProtected(PlaybackError):
    """The stream needs DRM, which this add-on does not handle."""


class Unsupported(PlaybackError):
    """The stream is in a format this add-on does not handle."""


class PlayerRefused(PlaybackError):
    def __init__(self, code):
        PlaybackError.__init__(self, code)
        self.code = code


def _hls(url):
    url = absolute_url(url)
    if url is None:
        raise Unsupported("stream URL is not https")
    try:
        path = urlsplit(url).path
    except ValueError:
        raise Unsupported("stream URL is malformed")
    if not path.endswith(".m3u8"):
        raise Unsupported("stream is not HLS")
    return url


def parse_video_url(text):
    """Stream URL from a get_video_url.php response."""
    try:
        payload = json.loads(text)
    except (ValueError, TypeError):
        raise ParseError("video URL response is not JSON")
    if not isinstance(payload, dict):
        raise ParseError("video URL response is not an object")
    if any(payload.get(field) for field in _DRM_FIELDS):
        raise DrmProtected("DRM fields are set")
    if not payload.get("url"):
        raise Unavailable(str(payload.get("error") or "no URL")[:80])
    return _hls(payload["url"])


def parse_player(page):
    """-> {"url", "subtitles"} from a player.php page."""
    if not isinstance(page, str):
        raise ParseError("player page is not text")
    match = _SETUP.search(page)
    if not match:
        code = _ERROR.search(page)
        if code:
            raise PlayerRefused(code.group(1))
        raise ParseError("player page has no setup")
    try:
        setup, _ = json.JSONDecoder().raw_decode(page, match.end())
    except ValueError:
        raise ParseError("player setup is not JSON")
    playlist = setup.get("playlist") if isinstance(setup, dict) else None
    entries = [e for e in playlist if isinstance(e, dict)] if isinstance(playlist, list) else []
    # Station idents ("bumper") can precede the programme itself.
    content = [e for e in entries if isinstance(e.get("file"), str) and "bumper" not in e["file"]]
    if not content:
        raise Unavailable("player playlist is empty")
    hls = [e for e in content if e.get("type") == "hls"]
    if not hls:
        raise Unsupported("no HLS entry in the playlist")
    entry = hls[0]
    subtitles = []
    for track in entry.get("tracks") or []:
        if isinstance(track, dict) and track.get("kind") in ("captions", "subtitles"):
            url = absolute_url(track.get("file"))
            if url:
                subtitles.append(url)
    return {"url": _hls(entry["file"]), "subtitles": subtitles}


def _player_request(token, subtitle_paths):
    url = "%s?video=%s&noflash=yes" % (PLAYER_URL, token)
    if subtitle_paths:
        url += "&subtitlePath=" + quote(subtitle_paths[0], safe="")
    return url


def resolve(client, token, subtitle_paths=(), referer="https://mediaklikk.hu/", log=None):
    """-> {"url", "mime", "subtitles"} for a token taken from an episode page.

    The token goes into the query exactly as the page gave it. A refusal is
    final: no retry with different headers or parameters."""
    log = log or (lambda message: None)
    stream = None
    try:
        stream = parse_video_url(client.fetch("%s?token=%s" % (VIDEO_URL, token)))
    except PlaybackError:
        raise
    except MediaklikkError as exc:
        log("video URL request failed (%s), trying the player page" % type(exc).__name__)
    subtitles = []
    if stream is None or subtitle_paths:
        try:
            player = parse_player(client.fetch(_player_request(token, list(subtitle_paths)),
                                               headers={"Referer": referer}))
            subtitles = player["subtitles"]
            stream = stream or player["url"]
        except MediaklikkError as exc:
            if stream is None:
                raise
            log("no subtitles: player page failed (%s)" % type(exc).__name__)
    return {"url": stream, "mime": HLS_MIME, "subtitles": subtitles}
