"""The programme catalogue: parsing, normalising, searching.

Primary source is the /musoraink page (genres, TV/radio flag, programme id,
16:9 image); the allMusor.json search index is the fallback. See
docs/feasibility.md section 4.

Pure Python: no Kodi imports.
"""
import html
import json
import re
import unicodedata
from urllib.parse import urlsplit

from mediaklikk.http import MediaklikkError, ParseError

MUSORAINK_URL = "https://mediaklikk.hu/musoraink"
ALLMUSOR_URL = "https://mediaklikk.hu/iface/mediaklikk/allPrograms/allMusor.json"

SOURCE_PAGE = "musoraink"
SOURCE_INDEX = "allmusor"
TV = "tv"
RADIO = "radio"
NO_GENRE = ""  # key of the "other" bucket for programmes without a genre

# The live page lists several hundred programmes; far fewer means the markup changed.
MIN_PROGRAMMES = 50
_BLOCK_LIMIT = 3000  # a programme item is well under this; keeps the last block out of the footer
_TYPES = {"tv": TV, "rádió": RADIO}
_SITE_HOSTS = ("mediaklikk.hu", "www.mediaklikk.hu")

_ITEM_SPLIT = re.compile(r'<div class="programItem')
_ID = re.compile(r'data-programId="(\d+)"')
_TYPE = re.compile(r'data-type="([^"]*)"')
_GENRE = re.compile(r'data-genre\s*=\s*"([^"]*)"')
_CHANNEL = re.compile(r'data-channel="([^"]*)"')
_HREF = re.compile(r'<a href="([^"]+)"')
_IMAGE = re.compile(r'data-src="([^"]+)"')
_TITLE = re.compile(r'<h3 class="programTitle"[^>]*>(.*?)</h3>', re.S)
_GENRE_FILTER = re.compile(r'data-genre="([^"]+)">.*?<p>(.*?)</p>', re.S)
_TAG = re.compile(r"<[^>]+>")


def absolute_url(url):
    """https URL from an absolute or protocol-relative one; None if unusable."""
    if not isinstance(url, str):
        return None
    url = url.strip()
    if url.startswith("//"):
        url = "https:" + url
    elif url.startswith("http://"):
        url = "https://" + url[len("http://"):]
    if not url.startswith("https://"):
        return None
    return url


def programme_url(url):
    """Normalised programme page URL on mediaklikk.hu, or None."""
    url = absolute_url(url)
    if url is None:
        return None
    try:
        parts = urlsplit(url)
    except ValueError:
        return None
    if parts.hostname not in _SITE_HOSTS or not parts.path.startswith("/musor/"):
        return None
    return "https://mediaklikk.hu" + parts.path.rstrip("/")


def _text(fragment):
    return " ".join(html.unescape(_TAG.sub("", fragment)).split())


def _first(pattern, text):
    match = pattern.search(text)
    return match.group(1) if match else None


def _dedupe(programmes):
    seen = set()
    unique = []
    for programme in programmes:
        if programme["url"] in seen:
            continue
        seen.add(programme["url"])
        unique.append(programme)
    return unique


def parse_musoraink(page, min_programmes=None):
    """-> {"programmes": [...], "genres": {slug: name}} from the /musoraink HTML."""
    if not isinstance(page, str):
        raise ParseError("programme page is not text")
    blocks = _ITEM_SPLIT.split(page)
    head, blocks = blocks[0], blocks[1:]
    genres = {}
    for slug, name in _GENRE_FILTER.findall(head):
        name = _text(name)
        if slug != "0" and name:
            genres[slug] = name
    programmes = []
    for block in blocks:
        block = block[:_BLOCK_LIMIT]
        title = _text(_first(_TITLE, block) or "")
        url = programme_url(html.unescape(_first(_HREF, block) or ""))
        if not title or not url:
            continue  # an item we cannot show or open is dropped, the rest of the list stays
        slugs = [s.strip() for s in (_first(_GENRE, block) or "").split(",") if s.strip()]
        programmes.append({
            "id": _first(_ID, block),
            "title": title,
            "url": url,
            "image": absolute_url(html.unescape(_first(_IMAGE, block) or "")),
            "type": _TYPES.get((_first(_TYPE, block) or "").strip().lower()),
            "genres": slugs,
            "channel": _first(_CHANNEL, block) or None,
        })
    programmes = _dedupe(programmes)
    if len(programmes) < (MIN_PROGRAMMES if min_programmes is None else min_programmes):
        raise ParseError("programme page yielded %d programmes" % len(programmes))
    return {"programmes": programmes, "genres": genres}


def parse_allmusor(text):
    """-> {"programmes": [...], "genres": {}} from the allMusor.json search index.
    Its items carry no id, type or genre."""
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        raise ParseError("programme index is not JSON")
    if not isinstance(data, list):
        raise ParseError("programme index is not a list")
    programmes = []
    for item in data:
        if not isinstance(item, dict):
            continue
        title = item.get("label") or item.get("value")
        url = programme_url(item.get("url"))
        if not isinstance(title, str) or not title.strip() or not url:
            continue
        programmes.append({
            "id": None,
            "title": " ".join(title.split()),
            "url": url,
            "image": absolute_url(item.get("icon")),
            "type": None,
            "genres": [],
            "channel": None,
        })
    programmes = _dedupe(programmes)
    if not programmes:
        raise ParseError("programme index is empty")
    return {"programmes": programmes, "genres": {}}


def load(client, min_programmes=None):
    """Fetch and parse the catalogue; falls back to the search index when the
    page fails. -> {"programmes", "genres", "source"}"""
    try:
        result = parse_musoraink(client.fetch(MUSORAINK_URL), min_programmes)
        result["source"] = SOURCE_PAGE
        return result
    except MediaklikkError as first_error:
        try:
            result = parse_allmusor(client.fetch(ALLMUSOR_URL))
        except MediaklikkError:
            raise first_error
        result["source"] = SOURCE_INDEX
        return result


def fold(text):
    """Lower-case, accent-free form for matching and sorting (é -> e, ő -> o)."""
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch)).casefold()


def by_title(programmes):
    return sorted(programmes, key=lambda p: (fold(p["title"]), p["title"]))


def visible(programmes, tv_only):
    """Radio programmes are hidden when tv_only; unknown types are kept."""
    if not tv_only:
        return list(programmes)
    return [p for p in programmes if p["type"] != RADIO]


def search(programmes, query):
    """Accent- and case-insensitive title search: prefix matches first."""
    needle = fold(" ".join(query.split()))
    if not needle:
        return []
    starts, contains = [], []
    for programme in programmes:
        title = fold(programme["title"])
        if title.startswith(needle):
            starts.append(programme)
        elif needle in title:
            contains.append(programme)
    return by_title(starts) + by_title(contains)


def in_genre(programmes, slug):
    if slug == NO_GENRE:
        return [p for p in programmes if not p["genres"]]
    return [p for p in programmes if slug in p["genres"]]


def genre_counts(programmes, genres):
    """[(slug, name, count)] for genres that have programmes, sorted by name;
    the no-genre bucket (name None) comes last. A slug the filter panel does
    not name is shown by its slug."""
    counts = {}
    for programme in programmes:
        for slug in programme["genres"] or [NO_GENRE]:
            counts[slug] = counts.get(slug, 0) + 1
    rows = [(slug, genres.get(slug, slug), count) for slug, count in counts.items() if slug != NO_GENRE]
    rows.sort(key=lambda row: fold(row[1]))
    if counts.get(NO_GENRE):
        rows.append((NO_GENRE, None, counts[NO_GENRE]))
    return rows
