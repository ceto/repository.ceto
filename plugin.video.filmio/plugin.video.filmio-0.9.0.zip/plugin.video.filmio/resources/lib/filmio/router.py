"""Maps plugin:// URLs to handlers and builds Kodi listings."""
from urllib.parse import parse_qsl, urlencode, urlsplit

from filmio import auth, cache, cms, http, kodiutil, mapping, models, playback, tmdb, user

STR_GENRES = 30004
STR_SEARCH = 30005
STR_ERROR = 30011
STR_NEXT_PAGE = 30012
STR_BY_GENRE = 30014
STR_BY_DECADE = 30015
STR_NETWORK_ERROR = 30017
STR_SERVER_ERROR = 30018
STR_NO_RESULTS = 30019
STR_SEARCH_HEADING = 30020
STR_FEATURED = 30021
STR_EMAIL = 30030
STR_PASSWORD = 30031
STR_SIGNED_IN = 30032
STR_SIGNED_OUT = 30033
STR_SESSION_EXPIRED = 30034
STR_SIGN_IN = 30035
STR_SIGN_IN_TO_PLAY = 30040
STR_NOT_ENTITLED = 30041
STR_NO_WIDEVINE = 30042
STR_SIGN_IN_FIRST = 30043
STR_ADD_MY_LIST = 30050
STR_REMOVE_MY_LIST = 30051
STR_ADDED_MY_LIST = 30052
STR_REMOVED_MY_LIST = 30053
STR_CACHE_CLEARED = 30054

# Navigation entries that only make sense for a signed-in user (Milestone C).
LOGIN_ONLY_PATHS = ("/sajat-lista",)

FILTER_PARAMS = cms.FILTER_KEYS

_MEDIATYPE = {models.MOVIE: "movie", models.SERIES: "tvshow", models.EPISODE: "episode"}
_CONTENT = {models.MOVIE: "movies", models.SERIES: "tvshows", models.EPISODE: "episodes"}


class Request(object):
    def __init__(self, base_url, handle, params):
        self.base_url = base_url
        self.handle = handle
        self.params = params
        self.signed_in = False
        self.mapping_loader = mapping.Mapping
        self._mapping = None
        self.meta_loader = lambda: tmdb.TmdbMeta(None, "")
        self._meta = None

    @property
    def meta(self):
        """TMDB metadata lookup (disabled without a TMDB key)."""
        if self._meta is None:
            try:
                self._meta = self.meta_loader()
            except Exception as exc:  # never let extra metadata break the add-on
                kodiutil.log_error("TMDB metadata unavailable: %s" % type(exc).__name__)
                self._meta = tmdb.TmdbMeta(None, "")
        return self._meta

    @property
    def mapping(self):
        """External ids (TMDB/IMDb), loaded on first use only."""
        if self._mapping is None:
            try:
                self._mapping = self.mapping_loader()
            except Exception as exc:  # a broken mapping must never break the add-on
                kodiutil.log_error("mapping unavailable: %s" % type(exc).__name__)
                self._mapping = mapping.Mapping()
        return self._mapping

    def url_for(self, **params):
        clean = {k: v for k, v in params.items() if v not in (None, "")}
        return self.base_url + "?" + urlencode(sorted(clean.items()))


def parse_argv(argv):
    """Kodi calls plugins with [base_url, handle, '?query', ...]."""
    base_url = argv[0]
    handle = int(argv[1])
    query = argv[2] if len(argv) > 2 else ""
    if query.startswith("?"):
        query = query[1:]
    return Request(base_url, handle, dict(parse_qsl(query)))


def user_agent():
    """The add-on's own, honest identification for every request it makes."""
    return "%s/%s (Kodi)" % (kodiutil.ADDON_ID, kodiutil.ADDON_VERSION)


def load_mapping():
    if not mapping.MAPPING_URL:
        return mapping.Mapping()
    store = mapping.MappingStore(kodiutil.profile_path("mapping.json"), mapping.MAPPING_URL,
                                 user_agent=user_agent(), log=kodiutil.log)
    return store.load()


def embedded_tmdb_credential():
    """The key a local personal build embedded (tools/build_zip.py
    --embed-tmdb-key); the module never exists in the repository or CI builds."""
    try:
        from filmio import _local_key
    except ImportError:
        return ""
    return getattr(_local_key, "TMDB_CREDENTIAL", "") or ""


def load_meta():
    # The add-on setting wins; otherwise a personal build's embedded key.
    credential = kodiutil.setting_str("tmdb_credential").strip() or embedded_tmdb_credential().strip()
    if not credential:
        return tmdb.TmdbMeta(None, "")
    return tmdb.TmdbMeta(credential, kodiutil.profile_path("tmdb.json"),
                         user_agent=user_agent(), log=kodiutil.log)


def make_client():
    client = http.HttpClient(user_agent(), logger=kodiutil.log)
    store = auth.SessionStore(kodiutil.profile_path("session.json"))
    session = auth.AuthSession(client, store, client_name="Kodi", client_version=kodiutil.ADDON_VERSION)
    reported = []

    def on_signed_out():
        if not reported:
            reported.append(True)
            kodiutil.notify(kodiutil.localize(STR_SESSION_EXPIRED))

    user_http = auth.UserHttp(session, client, on_signed_out)
    lang = "Magyar" if kodiutil.ui_language() == "hu" else "English"
    cached = cache.CachingHttp(client, kodiutil.profile_path("cache"))
    return cms.CmsClient(cached, lang=lang, user_http=user_http, session=session)


# --- listing helpers -------------------------------------------------------

def _folder(req, label, icon="DefaultFolder.png", **params):
    return req.url_for(**params), kodiutil.folder_item(label, icon), True


def _unique_ids(req, title):
    kind = {models.MOVIE: "movie", models.SERIES: "tvshow"}.get(title.kind)
    return req.mapping.unique_ids(title.id, kind) if kind else {}


def _info(title, unique_ids=None, listing=True):
    """Kodi video info for a title. listing=False leaves out the per-user
    state (watched, resume), which belongs to the list item, not the player."""
    info = {
        "title": title.title, "originaltitle": title.original_title,
        "tvshowtitle": title.show_title, "plot": title.plot,
        "plotoutline": title.outline, "year": title.year, "duration": title.duration,
        "genres": title.genres, "directors": title.directors, "cast": title.actors,
        "mpaa": title.age, "mediatype": _MEDIATYPE.get(title.kind),
        "season": title.season, "episode": title.episode,
        "uniqueids": unique_ids or None,
    }
    if listing:
        info["playcount"] = 1 if title.watched else None
        info["resume"] = (title.resume_position, title.duration) if title.resume_position else None
    return info


PREFETCH_BUDGET = 2.0  # seconds a listing may wait for TMDB data on its first view


def _tmdb_ref(req, title):
    """(kind, tmdb id) whose TMDB data describes this title: the film or
    series itself, or for an episode its series. None if not mapped."""
    if title.kind == models.EPISODE:
        filmio_id, kind = title.series_id, "tvshow"
    else:
        filmio_id, kind = title.id, {models.MOVIE: "movie", models.SERIES: "tvshow"}.get(title.kind)
    if not filmio_id or not kind:
        return None
    tmdb_id = req.mapping.unique_ids(filmio_id, kind).get("tmdb")
    return (kind, tmdb_id) if tmdb_id else None


def _meta(req, title, fetch=False):
    ref = _tmdb_ref(req, title)
    if not ref:
        return None
    return req.meta.fetch(*ref) if fetch else req.meta.cached(*ref)


def _prefetch(req, titles):
    """Ask TMDB for the listed titles' data (bounded wait); returns finish()."""
    refs = [ref for ref in (_tmdb_ref(req, t) for t in titles) if ref]
    if not refs:
        return lambda: None
    return req.meta.prefetch(refs, PREFETCH_BUDGET)


def _enrich(info, art, title, meta):
    """Filmio data is the base; TMDB fills in or replaces what it has more
    completely. Episodes only take the series' logo."""
    if meta is None:
        return
    if meta.logo:
        if title.kind == models.EPISODE:
            art["tvshow.clearlogo"] = meta.logo
        art["clearlogo"] = meta.logo
    if title.kind == models.EPISODE:
        return
    if meta.cast:
        info["cast"] = meta.cast
    info["directors"] = info.get("directors") or meta.directors
    info["plot"] = info.get("plot") or meta.overview
    for key, value in (("writers", meta.writers), ("studios", meta.studios), ("countries", meta.countries),
                       ("tagline", meta.tagline), ("premiered", meta.premiered), ("rating", meta.rating),
                       ("originaltitle", meta.original_title)):
        if value:
            info[key] = value


def _art(title):
    art = {"poster": title.poster, "fanart": title.fanart, "landscape": title.fanart,
           "icon": title.poster or title.fanart}
    if title.kind == models.EPISODE:
        art["thumb"] = title.fanart or title.poster
    else:
        art["thumb"] = title.poster or title.fanart
    return art


def _title_entry(req, title):
    info = _info(title, _unique_ids(req, title))
    art = _art(title)
    _enrich(info, art, title, _meta(req, title))

    if title.kind == models.SERIES:
        url, folder = req.url_for(action="series", id=title.id), True
    elif title.kind == models.GENRE:
        url, folder = req.url_for(action="genre", title=title.title), True
        art = {"icon": "DefaultGenre.png", "thumb": "DefaultGenre.png"}
    elif title.kind == models.TAG:
        url, folder = req.url_for(action="tag", title=title.title), True
        art = {"icon": "DefaultTags.png", "thumb": "DefaultTags.png"}
    else:
        url, folder = req.url_for(action="play", id=title.id, show=title.show_title,
                                  sid=title.series_id), False
    context = []
    if req.signed_in and title.kind in (models.MOVIE, models.SERIES):
        if title.bookmarked:
            context.append((kodiutil.localize(STR_REMOVE_MY_LIST),
                            req.url_for(action="bookmark_remove", id=title.id)))
        else:
            context.append((kodiutil.localize(STR_ADD_MY_LIST),
                            req.url_for(action="bookmark_add", id=title.id, title=title.title,
                                        ctype=title.collection_type)))
    item = kodiutil.media_item(title.title, info, art, playable=not folder, context=context)
    return url, item, folder


def _content_for(titles):
    kinds = set(t.kind for t in titles)
    return _CONTENT.get(kinds.pop(), "videos") if len(kinds) == 1 else "videos"


def _list_page(req, page, next_params, cache=True):
    if not page.items and page.page == 1:
        kodiutil.notify(kodiutil.localize(STR_NO_RESULTS))
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        return
    finish = _prefetch(req, page.items)
    entries = [_title_entry(req, t) for t in page.items]
    if page.has_next:
        label = kodiutil.localize(STR_NEXT_PAGE) % (page.page + 1, page.page_count)
        params = dict(next_params, page=page.page + 1)
        entries.append(_folder(req, label, "DefaultFolder.png", **params))
    kodiutil.set_content(req.handle, _content_for(page.items))
    kodiutil.add_items(req.handle, entries)
    kodiutil.end_directory(req.handle, cache=cache)
    finish()  # let late TMDB answers land in the cache for the next view


def _filters(params):
    return {k: params[k] for k in FILTER_PARAMS if params.get(k)}


# --- handlers --------------------------------------------------------------

def show_root(req, client):
    entries = []
    for entry in client.navigation():
        if entry.path.rstrip("/") in LOGIN_ONLY_PATHS and not client.signed_in:
            continue
        entries.append(_folder(req, entry.title, "DefaultAddonVideo.png",
                               action="dashboard", id=entry.dashboard_id))
    entries.append(_folder(req, kodiutil.localize(STR_GENRES), "DefaultGenre.png", action="genres"))
    entries.append(_folder(req, kodiutil.localize(STR_SEARCH), "DefaultAddonsSearch.png", action="search"))
    if not client.signed_in:
        item = kodiutil.folder_item(kodiutil.localize(STR_SIGN_IN), "DefaultUser.png")
        entries.append((req.url_for(action="login"), item, False))
    kodiutil.add_items(req.handle, entries)
    kodiutil.end_directory(req.handle)


def show_dashboard(req, client):
    dash = client.dashboard(req.params["id"])
    entries = []
    for row in dash.rows + dash.orders:
        label = row.title or kodiutil.localize(STR_FEATURED)
        entries.append(_folder(req, label, action="carousel", id=row.carousel_id))
    if dash.orders and dash.genres:
        entries.append(_folder(req, kodiutil.localize(STR_BY_GENRE), "DefaultGenre.png",
                               action="filters", dash=req.params["id"], kind="genres"))
    if dash.orders and dash.decades:
        entries.append(_folder(req, kodiutil.localize(STR_BY_DECADE), "DefaultYear.png",
                               action="filters", dash=req.params["id"], kind="releaseDate"))
    kodiutil.add_items(req.handle, entries)
    kodiutil.end_directory(req.handle)


def _filter_folders(req, dash, kind):
    target = dash.orders[0].carousel_id
    if kind == "genres":
        values = [(g, g) for g in dash.genres]
        icon = "DefaultGenre.png"
    else:
        values = [(d.title, d.slug) for d in dash.decades]
        icon = "DefaultYear.png"
    entries = [_folder(req, label, icon, action="carousel", id=target, **{kind: value})
               for label, value in values]
    kodiutil.add_items(req.handle, entries)
    kodiutil.end_directory(req.handle)


def show_filters(req, client):
    dash = client.dashboard(req.params["dash"])
    if not dash.orders:
        raise http.ParseError("dashboard has no filterable list")
    _filter_folders(req, dash, req.params.get("kind", "genres"))


def show_genres(req, client):
    dash_id = client.films_dashboard_id()
    dash = client.dashboard(dash_id) if dash_id else None
    if not dash or not dash.orders:
        raise http.ParseError("films dashboard not found")
    _filter_folders(req, dash, "genres")


def _films_filtered(req, client, key):
    dash_id = client.films_dashboard_id()
    dash = client.dashboard(dash_id) if dash_id else None
    if not dash or not dash.orders:
        raise http.ParseError("films dashboard not found")
    page_no = int(req.params.get("page", 1))
    filters = {key: req.params["title"]}
    page = client.carousel(dash.orders[0].carousel_id, page=page_no, filters=filters)
    _list_page(req, page, {"action": req.params["action"], "title": req.params["title"]})


def show_genre(req, client):
    _films_filtered(req, client, "genres")


def show_tag(req, client):
    _films_filtered(req, client, "tags")


def show_carousel(req, client):
    page_no = int(req.params.get("page", 1))
    filters = _filters(req.params)
    page = client.carousel(req.params["id"], page=page_no, filters=filters)
    _list_page(req, page, dict(filters, action="carousel", id=req.params["id"]))


def show_series(req, client):
    series = client.series(req.params["id"])
    seasons = [s for s in series.seasons if s[2]]
    if len(seasons) == 1:
        _list_episodes(req, seasons[0][2])
        return
    entries = [_folder(req, title or str(number), "DefaultTVShows.png",
                       action="season", id=req.params["id"], season=number)
               for title, number, _ in seasons]
    kodiutil.set_content(req.handle, "seasons")
    kodiutil.add_items(req.handle, entries)
    kodiutil.end_directory(req.handle)


def show_season(req, client):
    series = client.series(req.params["id"])
    wanted = int(req.params["season"])
    for _, number, episodes in series.seasons:
        if number == wanted:
            _list_episodes(req, episodes)
            return
    kodiutil.notify(kodiutil.localize(STR_NO_RESULTS))
    kodiutil.end_directory(req.handle, succeeded=False, cache=False)


def _list_episodes(req, episodes):
    finish = _prefetch(req, episodes[:1])  # episodes only need their series
    kodiutil.set_content(req.handle, "episodes")
    kodiutil.add_items(req.handle, [_title_entry(req, ep) for ep in episodes])
    kodiutil.end_directory(req.handle)
    finish()


def show_search(req, client):
    query = req.params.get("q")
    if not query:
        # Ask once, then move to a URL that carries the query. Kodi re-runs the
        # current URL when the user navigates back to it, so results must not
        # live under the bare ?action=search or the keyboard would pop up again.
        query = kodiutil.keyboard(kodiutil.localize(STR_SEARCH_HEADING))
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        if query:
            kodiutil.container_update(req.url_for(action="search", q=query))
        return
    page_no = int(req.params.get("page", 1))
    page = client.search(query, page=page_no)
    _list_page(req, page, {"action": "search", "q": query}, cache=False)


def login(req, client):
    email = kodiutil.keyboard(kodiutil.localize(STR_EMAIL))
    if not email:
        return
    password = kodiutil.keyboard(kodiutil.localize(STR_PASSWORD), hidden=True)
    if not password:
        return
    if client.session.signed_in:
        client.session.logout()  # free the old device slot before creating a new one
    try:
        client.session.login(email, password)
    except http.ApiError as exc:
        kodiutil.log_error("sign-in failed: status %s code %s" % (exc.status, exc.code))
        kodiutil.ok_dialog(exc.message(kodiutil.ui_language()) or kodiutil.localize(STR_SERVER_ERROR) % exc.status)
        return
    finally:
        password = None
    kodiutil.log("signed in")
    kodiutil.notify(kodiutil.localize(STR_SIGNED_IN))
    kodiutil.refresh_container()


def logout(req, client):
    client.session.logout()
    kodiutil.log("signed out")
    kodiutil.notify(kodiutil.localize(STR_SIGNED_OUT))
    kodiutil.refresh_container()


def bookmark_add(req, client):
    if not client.signed_in:
        kodiutil.ok_dialog(kodiutil.localize(STR_SIGN_IN_FIRST))
        return
    api = user.UserApi(client.session, client.base_url)
    api.add_bookmark(req.params["id"], req.params.get("title"),
                     req.params.get("ctype") or "api::asset.asset")
    kodiutil.notify(kodiutil.localize(STR_ADDED_MY_LIST))
    kodiutil.refresh_container()


def bookmark_remove(req, client):
    if not client.signed_in:
        kodiutil.ok_dialog(kodiutil.localize(STR_SIGN_IN_FIRST))
        return
    user.UserApi(client.session, client.base_url).remove_bookmark(req.params["id"])
    kodiutil.notify(kodiutil.localize(STR_REMOVED_MY_LIST))
    kodiutil.refresh_container()


def clear_cache(req, client):
    cache.CachingHttp(None, kodiutil.profile_path("cache")).clear()
    kodiutil.notify(kodiutil.localize(STR_CACHE_CLEARED))


def play(req, client):
    if not client.signed_in:
        kodiutil.resolve_failed(req.handle)
        kodiutil.ok_dialog(kodiutil.localize(STR_SIGN_IN_TO_PLAY))
        return
    asset = client.asset(req.params["id"])
    if not asset.video_id:
        raise http.ParseError("asset has no videoId")
    if not kodiutil.ensure_widevine():
        kodiutil.resolve_failed(req.handle)
        kodiutil.ok_dialog(kodiutil.localize(STR_NO_WIDEVINE))
        return
    api = playback.PlaybackApi(client.session, client.base_url)
    try:
        stream = api.stream(asset.video_id)
    except http.ApiError:
        raise  # the server explains itself (e.g. the two-stream limit)
    except http.HttpError as exc:
        if exc.status == 403:
            kodiutil.resolve_failed(req.handle)
            kodiutil.ok_dialog(kodiutil.localize(STR_NOT_ENTITLED))
            return
        raise
    # The manifest URL carries the access token in its path: log the host only.
    kodiutil.log("playing stream from %s" % (urlsplit(stream.url).hostname or "?"))
    asset.show_title = asset.show_title or req.params.get("show")
    asset.series_id = asset.series_id or req.params.get("sid")
    info, art = _info(asset, _unique_ids(req, asset), listing=False), _art(asset)
    _enrich(info, art, asset, _meta(req, asset, fetch=True))
    item = kodiutil.playable_item(stream.url, playback.isa_properties(stream), playback.MIME_DASH,
                                  info=info, art=art)
    kodiutil.resolve(req.handle, item)
    from filmio import player  # imports xbmc.Player; only needed once playback starts
    player.keep_session(api, stream, asset.id, asset.title, asset.duration)


HANDLERS = {
    "dashboard": show_dashboard,
    "filters": show_filters,
    "genres": show_genres,
    "genre": show_genre,
    "tag": show_tag,
    "carousel": show_carousel,
    "series": show_series,
    "season": show_season,
    "search": show_search,
    "play": play,
    "login": login,
    "logout": logout,
    "bookmark_add": bookmark_add,
    "bookmark_remove": bookmark_remove,
    "clear_cache": clear_cache,
}
NON_DIRECTORY_ACTIONS = ("play", "login", "logout", "bookmark_add", "bookmark_remove", "clear_cache")


def run(argv, client_factory=make_client, mapping_loader=load_mapping, meta_loader=load_meta):
    req = parse_argv(argv)
    req.mapping_loader = mapping_loader
    req.meta_loader = meta_loader
    action = req.params.get("action")
    kodiutil.log("route action=%s" % (action or "root"))
    handler = show_root if not action else HANDLERS.get(action)
    if handler is None:
        kodiutil.log_error("unknown action %r" % action)
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
        return
    try:
        client = client_factory()
        req.signed_in = client.signed_in
        handler(req, client)
        return
    except auth.AuthRequired:
        kodiutil.log_error("session required in %r" % action)
        message = kodiutil.localize(STR_SESSION_EXPIRED)
    except http.NetworkError as exc:
        kodiutil.log_error("network error in %r: %s" % (action, exc))
        message = kodiutil.localize(STR_NETWORK_ERROR)
    except http.ApiError as exc:
        kodiutil.log_error("API error in %r: status %s code %s" % (action, exc.status, exc.code))
        message = exc.message(kodiutil.ui_language()) or kodiutil.localize(STR_SERVER_ERROR) % exc.status
    except http.HttpError as exc:
        kodiutil.log_error("HTTP error in %r: %s" % (action, exc.status))
        message = kodiutil.localize(STR_SERVER_ERROR) % exc.status
    except Exception as exc:  # last-resort guard: never crash into Kodi's UI
        kodiutil.log_error("unhandled %s in action %r: %s" % (type(exc).__name__, action, exc))
        message = kodiutil.localize(STR_ERROR)
    kodiutil.notify_error(message)
    if action == "play":
        kodiutil.resolve_failed(req.handle)
    elif action not in NON_DIRECTORY_ACTIONS:
        kodiutil.end_directory(req.handle, succeeded=False, cache=False)
