"""Thin adapter over the Kodi API.

Everything that touches xbmc* modules lives here (and in router.py), so the
rest of the library stays importable and testable outside Kodi.
"""
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from filmio.http import redact_url  # noqa: F401  (re-exported for callers)

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_VERSION = ADDON.getAddonInfo("version")


def localize(string_id):
    return ADDON.getLocalizedString(string_id)


def ui_language():
    """Two-letter code of Kodi's interface language, e.g. 'hu' or 'en'."""
    try:
        return (xbmc.getLanguage(xbmc.ISO_639_1) or "en").lower()
    except Exception:
        return "en"


def debug_enabled():
    try:
        return ADDON.getSettingBool("debug_logging")
    except Exception:  # setting missing or wrong type: treat as off
        return False


def setting_str(key):
    try:
        return ADDON.getSettingString(key) or ""
    except Exception:
        return ""


def log(message, level=None):
    """Log to kodi.log. Debug messages are promoted to INFO when the add-on's
    own debug setting is on, so they show up without enabling Kodi debug mode.
    Callers must never pass secrets; use redact_url() for URLs."""
    if level is None:
        level = xbmc.LOGINFO if debug_enabled() else xbmc.LOGDEBUG
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)


def log_error(message):
    xbmc.log("[%s] %s" % (ADDON_ID, message), xbmc.LOGERROR)


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, time_ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, time_ms)


def notify_error(message):
    notify(message, xbmcgui.NOTIFICATION_ERROR, 6000)


def keyboard(heading, hidden=False):
    """Text input; returns None when cancelled or empty. hidden masks the
    input (passwords); the value is never logged."""
    option = xbmcgui.ALPHANUM_HIDE_INPUT if hidden else 0
    text = xbmcgui.Dialog().input(heading, type=xbmcgui.INPUT_ALPHANUM, option=option)
    text = text if hidden else (text or "").strip()
    return text or None


def ok_dialog(message):
    xbmcgui.Dialog().ok(ADDON_NAME, message)


def profile_path(*parts):
    """Absolute path inside the add-on's profile folder (special://profile/addon_data/<id>/)."""
    base = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    return os.path.join(base, *parts)


def refresh_container():
    xbmc.executebuiltin("Container.Refresh")


def folder_item(label, icon="DefaultFolder.png"):
    item = xbmcgui.ListItem(label=label, offscreen=True)
    item.setArt({"icon": icon, "thumb": icon})
    return item


_SETTERS = (
    ("title", "setTitle"), ("originaltitle", "setOriginalTitle"),
    ("tvshowtitle", "setTvShowTitle"),
    ("plot", "setPlot"), ("plotoutline", "setPlotOutline"),
    ("year", "setYear"), ("duration", "setDuration"),
    ("genres", "setGenres"), ("directors", "setDirectors"),
    ("mpaa", "setMpaa"), ("mediatype", "setMediaType"),
    ("season", "setSeason"), ("episode", "setEpisode"),
    ("playcount", "setPlaycount"),
    ("writers", "setWriters"), ("studios", "setStudios"), ("countries", "setCountries"),
    ("tagline", "setTagLine"), ("premiered", "setPremiered"),
)


def _apply_info(item, info, art):
    """Video metadata on a ListItem.

    info keys: title, originaltitle, tvshowtitle, plot, plotoutline, year,
    duration (s), genres, directors, writers, studios, countries, tagline,
    premiered (YYYY-MM-DD), mpaa, mediatype, season, episode, playcount,
    cast (names, or dicts with name/role/thumb/order),
    rating ((value, votes) from TMDB), resume (position s, total s),
    uniqueids ({"tmdb": "1", "imdb": "tt..."}; the default is imdb if present).
    """
    if art:
        item.setArt({k: v for k, v in art.items() if v})
    tag = item.getVideoInfoTag()
    for key, setter in _SETTERS:
        value = info.get(key)
        if value not in (None, "", []):
            getattr(tag, setter)(value)
    if info.get("cast"):
        actors = []
        for person in info["cast"]:
            if isinstance(person, dict):
                actors.append(xbmc.Actor(person["name"], person.get("role", ""), person.get("order", -1),
                                         person.get("thumb", "")))
            else:
                actors.append(xbmc.Actor(person))
        tag.setCast(actors)
    if info.get("rating"):
        value, votes = info["rating"]
        tag.setRating(float(value), int(votes), "themoviedb", True)
    if info.get("resume"):
        position, total = info["resume"]
        tag.setResumePoint(float(position), float(total or 0))
    ids = info.get("uniqueids")
    if ids:
        tag.setUniqueIDs(dict(ids), "imdb" if "imdb" in ids else "tmdb")


def media_item(label, info, art, playable=False, context=None):
    """ListItem for a directory listing (see _apply_info for info keys).
    context: [(label, plugin url)] entries for the context menu, run via RunPlugin."""
    item = xbmcgui.ListItem(label=label, offscreen=True)
    _apply_info(item, info, art)
    if context:
        item.addContextMenuItems([(text, "RunPlugin(%s)" % url) for text, url in context])
    item.setProperty("IsPlayable", "true" if playable else "false")
    return item


def ensure_widevine():
    """Checks (and if needed offers to install) inputstream.adaptive and the
    Widevine CDM. The user confirms any installation in Kodi's own dialogs."""
    import inputstreamhelper  # Kodi add-on dependency, only importable inside Kodi
    return bool(inputstreamhelper.Helper("mpd", drm="com.widevine.alpha").check_inputstream())


def playable_item(url, properties, mime_type, info=None, art=None):
    """The resolved item handed to the player. info/art (see _apply_info)
    describe what is playing, for Kodi's OSD and for scrobblers."""
    item = xbmcgui.ListItem(path=url, offscreen=True)
    if info:
        _apply_info(item, info, art)
    item.setMimeType(mime_type)
    item.setContentLookup(False)
    for key, value in properties.items():
        item.setProperty(key, value)
    return item


def resolve(handle, item):
    xbmcplugin.setResolvedUrl(handle, True, item)


def resolve_failed(handle):
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))


def add_items(handle, items):
    """items: iterable of (url, ListItem, is_folder)."""
    xbmcplugin.addDirectoryItems(handle, list(items))


def set_content(handle, content):
    xbmcplugin.setContent(handle, content)


def container_update(url):
    """Navigate the current window to url (adds a history entry)."""
    xbmc.executebuiltin("Container.Update(%s)" % url)


def end_directory(handle, succeeded=True, cache=True):
    xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=cache)
