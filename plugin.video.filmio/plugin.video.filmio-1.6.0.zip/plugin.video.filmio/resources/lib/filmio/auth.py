"""Sign-in, token refresh and authorised requests (Filmio CRM API).

Flow verified against the official web client (docs/feasibility.md §12–13):
- POST {CRM}/auth/login   {email, password} -> data.{accessToken, refreshToken, deviceUUID}
- POST {CRM}/auth/refresh {refreshToken}    -> same shape
- POST {CRM}/auth/logout  {refreshToken}    -> removes the device server-side
Authorised calls send Authorization: Bearer, device-type and device-uuid.
The API exposes no token lifetime, so expiry is handled by refresh-on-401.

When a refresh is rejected, the session signs in again on its own with the
saved e-mail and password (CredentialStore), if the user lets the add-on
remember the password (the default). Without a saved password the user has
to sign in again.

Pure Python: no Kodi imports. Tokens and credentials live in private files in
the profile folder and are never logged.
"""
import json
import os
import threading

from filmio.http import ApiError, FilmioError, HttpError

CRM_URL = "https://crm-prod-filmio.connectmedia.hu/api"
DEVICE_TYPE = "WEB"  # the only value the backend is known to accept from non-app clients


class AuthRequired(FilmioError):
    """No valid session: the user has to sign in (again)."""


def _write_private(path, data):
    """JSON file readable only by the current user (where the OS allows)."""
    directory = os.path.dirname(path)
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    os.replace(tmp, path)


def _remove(path):
    for name in (path, path + ".tmp"):
        try:
            os.remove(name)
        except OSError:
            pass


class SessionStore(object):
    """Tokens in a JSON file readable only by the current user (where the OS allows)."""

    KEYS = ("access_token", "refresh_token", "device_uuid")

    def __init__(self, path):
        self.path = path

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return None
        if not isinstance(data, dict) or not data.get("access_token") or not data.get("refresh_token"):
            return None
        return {k: data.get(k) for k in self.KEYS}

    def save(self, tokens):
        _write_private(self.path, {k: tokens.get(k) for k in self.KEYS})

    def clear(self):
        _remove(self.path)


class CredentialStore(object):
    """The e-mail used to sign in, and the password if remember_password is on."""

    def __init__(self, path, remember_password=True):
        self.path = path
        self.remember_password = remember_password

    def load(self):
        """(email, password); empty strings for what is not saved."""
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return "", ""
        if not isinstance(data, dict):
            return "", ""
        email = data.get("email") if isinstance(data.get("email"), str) else ""
        password = data.get("password") if isinstance(data.get("password"), str) else ""
        return email, (password if self.remember_password else "")

    def save(self, email, password):
        data = {"email": email}
        if self.remember_password and password:
            data["password"] = password
        try:
            _write_private(self.path, data)
        except OSError:
            pass  # a convenience only: signing in already worked

    def forget_password(self):
        email, password = CredentialStore(self.path).load()
        if not password:
            return
        if email:
            try:
                _write_private(self.path, {"email": email})
                return
            except OSError:
                pass
        _remove(self.path)


def _tokens_from(payload):
    data = (payload or {}).get("data") or {}
    if not data.get("accessToken") or not data.get("refreshToken"):
        raise ApiError(500, None, {"en": "sign-in response without tokens"})
    return {"access_token": data["accessToken"], "refresh_token": data["refreshToken"],
            "device_uuid": data.get("deviceUUID")}


class AuthSession(object):
    def __init__(self, http, store, client_name="Kodi", client_version="", crm_url=CRM_URL, credentials=None):
        self.http = http
        self.store = store
        self.credentials = credentials
        self.crm_url = crm_url.rstrip("/")
        self.client_name = client_name
        self.client_version = client_version
        self._tokens = store.load()
        self._lock = threading.Lock()  # heartbeat and progress calls run on two threads

    @property
    def signed_in(self):
        return self._tokens is not None

    def _post(self, path, body, headers):
        hdrs = {"device_type": DEVICE_TYPE}
        hdrs.update(headers)
        return self.http.request_json("POST", self.crm_url + path, body=body, headers=hdrs)

    def login(self, email, password):
        payload = self._post("/auth/login", {"email": email, "password": password}, {
            "app_version": self.client_version,
            "device_os": self.client_name,
            "browser_name": self.client_name,
            "browser_version": self.client_version,
        })
        self._tokens = _tokens_from(payload)
        self.store.save(self._tokens)
        if self.credentials:
            self.credentials.save(email, password)

    def saved_login(self):
        """(email, password) saved by an earlier sign-in; empty strings if none."""
        return self.credentials.load() if self.credentials else ("", "")

    def logout(self):
        """Best effort server-side logout (frees the device slot); always clears
        locally. The e-mail stays saved for the next sign-in, the password not."""
        tokens, self._tokens = self._tokens, None
        self.store.clear()
        if self.credentials:
            self.credentials.forget_password()
        if tokens:
            try:
                self._post("/auth/logout", {"refreshToken": tokens["refresh_token"]}, {})
            except FilmioError:
                pass

    def refresh(self):
        if not self._tokens:
            raise AuthRequired("not signed in")
        try:
            payload = self._post("/auth/refresh", {"refreshToken": self._tokens["refresh_token"]}, {})
        except HttpError as exc:
            if exc.status in (400, 401, 403):
                self._tokens = None
                self.store.clear()
                self._login_again()
                return
            raise
        tokens = _tokens_from(payload)
        if not tokens.get("device_uuid"):
            tokens["device_uuid"] = self._tokens.get("device_uuid")
        self._tokens = tokens
        self.store.save(tokens)

    def _login_again(self):
        """Silent sign-in with the saved credentials; AuthRequired without them
        or when the server rejects them (the password is then forgotten)."""
        email, password = self.saved_login()
        if not email or not password:
            raise AuthRequired("session expired")
        try:
            self.login(email, password)
        except HttpError as exc:
            if exc.status in (400, 401, 403):
                self.credentials.forget_password()
                raise AuthRequired("saved credentials rejected")
            raise

    def auth_headers(self):
        if not self._tokens:
            raise AuthRequired("not signed in")
        headers = {"Authorization": "Bearer " + self._tokens["access_token"], "device-type": DEVICE_TYPE}
        if self._tokens.get("device_uuid"):
            headers["device-uuid"] = self._tokens["device_uuid"]
        return headers

    def request_json(self, method, url, params=None, body=None):
        """Authorised request; refreshes the token once on 401/403 and retries.

        Thread-safe: if another thread already refreshed the token in the
        meantime, the retry just uses the new one (refresh tokens may be
        single-use, so refreshing twice could sign the user out)."""
        headers = self.auth_headers()
        try:
            return self.http.request_json(method, url, params=params, body=body, headers=headers)
        except HttpError as exc:
            if exc.status not in (401, 403):
                raise
        with self._lock:
            if self.auth_headers()["Authorization"] == headers["Authorization"]:
                self.refresh()
        return self.http.request_json(method, url, params=params, body=body, headers=self.auth_headers())

    def get_json(self, url, params=None, headers=None):
        return self.request_json("GET", url, params=params)


class UserHttp(object):
    """get_json() that is authorised when signed in and anonymous otherwise.

    Used for catalogue calls that return per-user data (continue watching,
    my list, view positions). If the session turns out to be dead, it falls
    back to an anonymous request and reports it once via on_signed_out.
    """

    def __init__(self, session, public_http, on_signed_out=None):
        self.session = session
        self.public = public_http
        self.on_signed_out = on_signed_out or (lambda: None)

    def get_json(self, url, params=None, headers=None):
        if self.session.signed_in:
            try:
                return self.session.get_json(url, params=params)
            except AuthRequired:
                self.on_signed_out()
        return self.public.get_json(url, params=params)
