"""Small on-disk cache for anonymous, slowly changing catalogue responses
(config, navigation, dashboards). Per-user responses are never cached.

Pure Python: no Kodi imports. Any cache problem degrades to a live request.
"""
import hashlib
import json
import os
import time

DEFAULT_TTL = 15 * 60  # seconds


class CachingHttp(object):
    def __init__(self, http, directory, ttl=DEFAULT_TTL, clock=time.time):
        self.http = http
        self.directory = directory
        self.ttl = ttl
        self.clock = clock

    def _path(self, url, params):
        key = json.dumps([url, sorted(params.items()) if isinstance(params, dict) else params], sort_keys=True)
        return os.path.join(self.directory, hashlib.sha1(key.encode("utf-8")).hexdigest() + ".json")

    def get_json(self, url, params=None, headers=None):
        path = self._path(url, params)
        try:
            with open(path, encoding="utf-8") as fh:
                entry = json.load(fh)
            if self.clock() - entry["stored"] < self.ttl:
                return entry["payload"]
        except (OSError, ValueError, KeyError, TypeError):
            pass
        payload = self.http.get_json(url, params=params)
        try:
            if not os.path.isdir(self.directory):
                os.makedirs(self.directory)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"stored": self.clock(), "payload": payload}, fh)
            os.replace(tmp, path)
        except OSError:
            pass
        return payload

    def clear(self):
        try:
            names = os.listdir(self.directory)
        except OSError:
            return
        for name in names:
            if name.endswith(".json") or name.endswith(".tmp"):
                try:
                    os.remove(os.path.join(self.directory, name))
                except OSError:
                    pass
