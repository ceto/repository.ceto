"""Small JSON-over-HTTPS client on top of urllib (no third-party packages).

Pure Python: no Kodi imports, so it is testable on the host.
"""
import json
import re
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen

DEFAULT_TIMEOUT = 15

# Path segments that look like tokens or long opaque ids (the CDN and license
# URLs carry the access token in the path).
_TOKENISH = re.compile(r"[A-Za-z0-9_.~-]{20,}")


def redact_url(url):
    """Return the URL without query, fragment, userinfo or token-like path segments."""
    try:
        parts = urlsplit(url)
        host = parts.hostname or ""
        if parts.port:
            host = "%s:%d" % (host, parts.port)
    except ValueError:
        return "<invalid url>"
    path = "/".join(_TOKENISH.sub("<redacted>", seg) for seg in parts.path.split("/"))
    return urlunsplit((parts.scheme, host, path, "", ""))


class FilmioError(Exception):
    """Base class for all errors raised by the Filmio client."""


class NetworkError(FilmioError):
    """DNS failure, refused connection, TLS problem or timeout."""


class HttpError(FilmioError):
    def __init__(self, status):
        FilmioError.__init__(self, "HTTP %d" % status)
        self.status = status


class ApiError(HttpError):
    """A Strapi-style error envelope: {"data": null, "error": {...}}."""

    def __init__(self, status, code=None, messages=None):
        HttpError.__init__(self, status)
        self.code = code
        self.messages = messages or {}

    def message(self, lang="hu"):
        return self.messages.get(lang) or self.messages.get("en") or self.messages.get("hu") or ""


class ParseError(FilmioError):
    """The response was not the JSON we expected."""


def _api_error(status, payload):
    err = payload.get("error") if isinstance(payload, dict) else None
    if not isinstance(err, dict):
        return None
    msg = err.get("message")
    if isinstance(msg, dict):
        messages = {k: v for k, v in msg.items() if isinstance(v, str)}
    elif isinstance(msg, str):
        messages = {"en": msg}
    else:
        messages = {}
    return ApiError(err.get("status") or err.get("statusCode") or status, err.get("errorCode"), messages)


def build_url(url, params=None):
    if not params:
        return url
    pairs = [(k, v) for k, v in params if v is not None] if isinstance(params, list) else \
        [(k, v) for k, v in sorted(params.items()) if v is not None]
    return url + ("&" if "?" in url else "?") + urlencode(pairs)


class HttpClient(object):
    def __init__(self, user_agent, timeout=DEFAULT_TIMEOUT, opener=urlopen, logger=None):
        self.user_agent = user_agent
        self.timeout = timeout
        self._open = opener
        self._log = logger or (lambda msg: None)

    def get_json(self, url, params=None, headers=None):
        return self.request_json("GET", url, params=params, headers=headers)

    def request_json(self, method, url, params=None, body=None, headers=None):
        full_url = build_url(url, params)
        hdrs = {"Accept": "application/json", "User-Agent": self.user_agent}
        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            hdrs["Content-Type"] = "application/json"
        hdrs.update(headers or {})
        req = Request(full_url, data=data, headers=hdrs, method=method)
        who = " (signed in)" if "Authorization" in hdrs else ""
        try:
            resp = self._open(req, timeout=self.timeout)
            status = getattr(resp, "status", None) or resp.getcode()
            raw = resp.read()
        except HTTPError as exc:
            self._log("%s %s%s -> %d" % (method, redact_url(full_url), who, exc.code))
            payload = None
            try:
                payload = json.loads(exc.read().decode("utf-8"))
            except Exception:  # error bodies are best effort
                pass
            finally:
                exc.close()
            raise _api_error(exc.code, payload) or HttpError(exc.code)
        except (URLError, socket.timeout, ConnectionError) as exc:
            self._log("%s %s -> network error (%s)" % (method, redact_url(full_url), type(exc).__name__))
            raise NetworkError(type(exc).__name__)
        self._log("%s %s%s -> %d" % (method, redact_url(full_url), who, status))
        if not raw:
            return None
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ParseError("response is not JSON")
        err = _api_error(status, payload)
        if err is not None:
            raise err
        return payload
