"""Normalisation of Filmio CMS (Strapi) JSON into plain objects.

Pure Python. The API is undocumented, so every accessor tolerates missing,
null or differently shaped fields: list responses carry genres/actors as
strings or {name} objects and ageRating as a list, detail responses carry
objects and a dict.
"""
import re
from collections import namedtuple

MOVIE, SERIES, EPISODE, GENRE, TAG = "movie", "series", "episode", "genre", "tag"
_KINDS = {"MOVIE": MOVIE, "SERIES": SERIES, "EPISODE": EPISODE, "GENRE": GENRE, "TAG": TAG}

# Strapi stores resized copies as <format>_<file>; the original is the same
# path without the prefix. The API hands out "small_" (about 500 px).
_STRAPI_FORMAT = re.compile(r"/uploads/(?:thumbnail|small|medium|large)_")

Row = namedtuple("Row", "title carousel_id")
NavEntry = namedtuple("NavEntry", "title path dashboard_id")
Decade = namedtuple("Decade", "title slug")


class Title(object):
    __slots__ = ("kind", "id", "slug", "title", "original_title", "plot", "outline", "year",
                 "duration", "genres", "directors", "actors", "age", "poster", "fanart",
                 "video_id", "season", "episode", "collection_type",
                 "resume_position", "watched", "bookmarked",
                 "series_id", "show_title")

    def __init__(self, **kw):
        for name in self.__slots__:
            setattr(self, name, kw.get(name))

    @property
    def playable(self):
        return self.kind in (MOVIE, EPISODE)


class Page(object):
    def __init__(self, items, page, page_size, total):
        self.items = items
        self.page = page
        self.page_size = page_size
        self.total = total

    @property
    def page_count(self):
        # meta.pagination.pageCount from the API is wrong (it echoes the item
        # count of the page), so it is derived from total instead.
        if not self.page_size:
            return 1
        return max(1, -(-self.total // self.page_size))

    @property
    def has_next(self):
        return self.page * self.page_size < self.total


class Dashboard(object):
    def __init__(self, title, rows, orders, genres, decades):
        self.title = title
        self.rows = rows          # [Row] content blocks
        self.orders = orders      # [Row] full lists that accept filters
        self.genres = genres      # [str] genre titles (filter value is the title)
        self.decades = decades    # [Decade]


class Series(object):
    def __init__(self, title, seasons, actors=None):
        self.title = title
        self.seasons = seasons    # [(season title, season number, [Title])]
        self.actors = actors or []


def full_size(url):
    if not url:
        return None
    return _STRAPI_FORMAT.sub("/uploads/", url, count=1)


def plain_text(blocks):
    """Flatten Strapi rich text (list of blocks with nested children) to text."""
    if isinstance(blocks, str):
        return blocks.strip()
    if not isinstance(blocks, list):
        return ""
    paragraphs = []
    for block in blocks:
        text = _inline_text(block).strip()
        if text:
            paragraphs.append(text)
    return "\n\n".join(paragraphs)


def _inline_text(node):
    if isinstance(node, dict):
        if node.get("type") == "text" or ("text" in node and "children" not in node):
            return node.get("text") or ""
        children = node.get("children") or []
        sep = "\n" if node.get("type") == "list" else ""
        return sep.join(_inline_text(c) for c in children)
    if isinstance(node, list):
        return "".join(_inline_text(c) for c in node)
    return ""


def description(raw, lang="Magyar"):
    """Pick the long description in the preferred language, falling back to any."""
    if isinstance(raw, str):
        return raw.strip()
    if not isinstance(raw, list):
        return ""
    entries = [d for d in raw if isinstance(d, dict)]
    preferred = [d for d in entries if d.get("language") == lang] + entries
    for entry in preferred:
        text = plain_text(entry.get("long"))
        if text:
            return text
    return ""


def names(values):
    out = []
    for v in values or []:
        if isinstance(v, str):
            name = v
        elif isinstance(v, dict):
            name = v.get("name") or v.get("title")
        else:
            name = None
        if name:
            out.append(name.strip())
    return out


def age_rating(raw):
    if isinstance(raw, list):
        raw = raw[0] if raw else None
    if isinstance(raw, dict) and raw.get("age"):
        return str(raw["age"])
    return None


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


WATCHED_STATUSES = ("WATCHED", "FINISHED")


def view_state(view, duration):
    """(resume position in seconds or None, watched) from a per-user 'view'
    object: {position, length, viewStatus: STARTED | WATCHED | FINISHED}."""
    if not isinstance(view, dict):
        return None, False
    watched = view.get("viewStatus") in WATCHED_STATUSES
    position = _int(view.get("position"))
    total = _int(view.get("length")) or duration
    if watched or not position or position <= 0 or (total and position >= total):
        return None, watched
    return position, False


def title_from(item, lang="Magyar"):
    """Build a Title from a carousel item, asset, series or episode. Returns
    None for kinds the add-on does not know."""
    if not isinstance(item, dict) or not item.get("id"):
        return None
    kind = _KINDS.get(item.get("type"))
    if kind is None:
        return None
    short = (item.get("short") or "").strip()
    cover = full_size(item.get("cover"))
    duration = _int(item.get("length"))
    resume, watched = view_state(item.get("view"), duration)
    return Title(
        kind=kind,
        id=item["id"],
        slug=item.get("slug"),
        title=(item.get("title") or item.get("name") or "").strip(),
        original_title=item.get("originalTitle"),
        plot=description(item.get("description"), lang) or short,
        outline=short,
        year=_int(item.get("year")),
        duration=duration,
        genres=names(item.get("genres")),
        directors=names(item.get("directors")),
        actors=names(item.get("actors")),
        age=age_rating(item.get("ageRating")),
        poster=full_size(item.get("poster")),
        fanart=cover,
        video_id=item.get("videoId"),
        season=_int(item.get("seasonNumber")),
        episode=_int(item.get("episodeNumber")),
        collection_type=item.get("collectionType") or (
            "api::series.series" if kind == SERIES else "api::asset.asset"),
        resume_position=resume,
        watched=watched,
        bookmarked=bool(item.get("bookmark") or item.get("hasBookmark")),
    )


def page_from(payload, lang="Magyar"):
    data = payload.get("data") if isinstance(payload, dict) else None
    if data is None:
        data = []
    if not isinstance(data, list):
        raise ValueError("carousel data is not a list")
    pagination = ((payload.get("meta") or {}).get("pagination") or {})
    items = [t for t in (title_from(x, lang) for x in data) if t is not None]
    page = _int(pagination.get("page")) or 1
    size = _int(pagination.get("pageSize")) or len(data)
    total = _int(pagination.get("total"))
    if total is None:
        total = (page - 1) * size + len(data)
    return Page(items, page, size, total)


def navigation_from(payload):
    entries = []
    for node in payload if isinstance(payload, list) else []:
        related = node.get("related") if isinstance(node, dict) else None
        if not isinstance(related, dict) or related.get("uid") != "api::dashboard.dashboard":
            continue
        if node.get("title") and related.get("id"):
            entries.append(NavEntry(node["title"], node.get("path") or "", related["id"]))
    return entries


def _rows(blocks):
    rows = []
    for block in blocks or []:
        if isinstance(block, dict) and block.get("carouselId"):
            rows.append(Row((block.get("title") or "").strip(), block["carouselId"]))
    return rows


def dashboard_from(payload):
    data = (payload or {}).get("data") or {}
    feature = data.get("feature") or {}
    rows = _rows(data.get("blocks"))
    if feature.get("component") == "feature.my-list":
        # "Saját lista": tabs (saved films, reminders) are per-user carousels.
        rows += _rows(feature.get("tabs"))
    if feature.get("component") != "feature.filter":
        feature = {}
    genres = names(feature.get("genres")) if feature.get("enableGenreFilter") else []
    decades = []
    if feature.get("enableReleaseDateFilter"):
        for d in feature.get("releaseDates") or []:
            if isinstance(d, dict) and d.get("slug"):
                decades.append(Decade(d.get("title") or d["slug"], d["slug"]))
    return Dashboard((data.get("title") or "").strip(), rows,
                     _rows(feature.get("orders")), genres, decades)


def series_from(payload, lang="Magyar"):
    data = (payload or {}).get("data") or {}
    seasons = []
    for index, season in enumerate(data.get("seasons") or [], 1):
        episodes = []
        for ep in season.get("episodes") or []:
            ep = dict(ep)
            ep.setdefault("type", "EPISODE")
            title = title_from(ep, lang)
            if title is not None:
                title.series_id = data.get("id")
                title.show_title = (data.get("title") or "").strip() or None
                episodes.append(title)
        number = episodes[0].season if episodes and episodes[0].season else index
        seasons.append(((season.get("title") or "").strip(), number, episodes))
    return Series((data.get("title") or "").strip(), seasons, names(data.get("actors")))
