"""Bridges Kodi's player to playback.keep_alive() (Kodi-facing)."""
import time

import xbmc

from filmio import kodiutil, playback


class _Player(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.file = None
        self.ended = False

    def onAVStarted(self):
        if self.file is None:
            try:
                self.file = self.getPlayingFile()
            except RuntimeError:
                self.file = ""

    def onPlayBackStopped(self):
        self.ended = True

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackError(self):
        self.ended = True


def keep_session(api, stream, asset_id, title, length):
    """Blocks until playback of the resolved stream is over."""
    player = _Player()
    monitor = xbmc.Monitor()

    def state():
        if monitor.abortRequested():
            return playback.ABORTED, None
        if player.ended:
            return playback.ENDED, None
        if player.file is None:
            # onAVStarted may have fired before this player object existed.
            try:
                if player.isPlayingVideo() and player.getTime() > 0:
                    player.file = player.getPlayingFile()
            except RuntimeError:
                pass
            if player.file is None:
                return playback.STARTING, None
        try:
            if not player.isPlayingVideo() or player.getPlayingFile() != player.file:
                return playback.ENDED, None  # stopped, or something else is playing now
            position = player.getTime()
        except RuntimeError:
            return playback.ENDED, None
        paused = xbmc.getCondVisibility("Player.Paused")
        return (playback.PAUSED if paused else playback.PLAYING), position

    started, position = playback.keep_alive(
        api, stream, asset_id, title, length, state,
        wait=monitor.waitForAbort, clock=time.monotonic, log=kodiutil.log)
    kodiutil.log("playback session closed (started=%s, position=%ds)" % (started, int(position)))
