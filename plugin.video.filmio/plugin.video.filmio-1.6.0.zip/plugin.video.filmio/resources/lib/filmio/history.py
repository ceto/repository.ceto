"""Recent search queries, kept locally in the add-on's profile folder.

Pure Python: no Kodi imports. A missing or broken file reads as empty history.
"""
import json
import os

MAX_ENTRIES = 30


class SearchHistory(object):
    def __init__(self, path, limit=MAX_ENTRIES):
        self.path = path
        self.limit = limit

    def load(self):
        """Queries, most recent first."""
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return []
        queries = data.get("queries") if isinstance(data, dict) else None
        if not isinstance(queries, list):
            return []
        return [q for q in queries if isinstance(q, str) and q.strip()]

    def add(self, query):
        """Moves query to the top; repeats differing only in case collapse into one."""
        query = (query or "").strip()
        if not query:
            return
        key = query.casefold()
        queries = [query] + [q for q in self.load() if q.casefold() != key]
        self._save(queries[:self.limit])

    def remove(self, query):
        key = (query or "").strip().casefold()
        queries = self.load()
        kept = [q for q in queries if q.casefold() != key]
        if kept != queries:
            self._save(kept)

    def clear(self):
        try:
            os.remove(self.path)
        except OSError:
            pass

    def _save(self, queries):
        try:
            directory = os.path.dirname(self.path)
            if directory and not os.path.isdir(directory):
                os.makedirs(directory)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"version": 1, "queries": queries}, fh, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass  # history is a convenience; never break a search over it
