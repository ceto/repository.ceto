"""Richer metadata straight from TMDB for titles that have a TMDB id.

The TMDB id comes from the external mapping (mapping.py). One request per
title (details + credits + images) gives the cast with roles and photos,
writers, studios, countries, tagline, rating, premiere date, original title
and the clearlogo. It uses the user's own TMDB key (add-on setting, or a key
embedded in a personal build). Results are cached in the profile folder, well
inside TMDB's 6-month caching limit.

Any problem (no key, network, HTTP error, unknown title) means "no TMDB data":
the add-on then shows Filmio's own metadata, and browsing and playback are
never affected.

Pure Python: no Kodi imports.
"""
import json
import os
import re
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

API = "https://api.themoviedb.org/3"
IMAGE_BASE = "https://image.tmdb.org/t/p/"
LOGO_SIZE = "w500"      # plenty for an on-screen clearlogo
PROFILE_SIZE = "w185"   # cast photos
TIMEOUT = 3             # seconds per request
FOUND_TTL = 30 * 86400
NONE_TTL = 7 * 86400
ERROR_TTL = 3600
MAX_CAST = 30
MAX_WRITERS = 6
WORKERS = 6

# Kodi cannot render SVG; for Hungarian films a Hungarian logo comes first.
LANGUAGE_RANK = {"hu": 0, None: 1, "en": 2}
_V3_KEY = re.compile(r"^[0-9a-f]{32}$")
_IMAGE_PATH = re.compile(r"^/[A-Za-z0-9_-]+\.(png|jpg)$")
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def auth(credential):
    """(headers, query params) for a v3 API key or a v4 read access token,
    or None if the value is neither."""
    credential = (credential or "").strip()
    if _V3_KEY.match(credential):
        return {}, [("api_key", credential)]
    if credential.startswith("eyJ") and credential.count(".") == 2:
        return {"Authorization": "Bearer " + credential}, []
    return None


def pick_logo(images):
    """Image path of the best PNG logo in a TMDB images object, or None."""
    logos = (images or {}).get("logos") or []
    usable = [l for l in logos
              if isinstance(l, dict) and (l.get("file_path") or "").endswith(".png")
              and _IMAGE_PATH.match(l.get("file_path") or "") and l.get("iso_639_1") in LANGUAGE_RANK]
    if not usable:
        return None
    best = min(usable, key=lambda l: (LANGUAGE_RANK[l.get("iso_639_1")],
                                      -(l.get("vote_average") or 0), -(l.get("width") or 0)))
    return best["file_path"]


def _names(items, key="name", limit=None):
    out = []
    for item in items or []:
        name = (item.get(key) or "").strip() if isinstance(item, dict) else ""
        if name and name not in out:
            out.append(name)
    return out[:limit] if limit else out


def extract(kind, data):
    """The compact record that is cached: only what the add-on shows."""
    credits = data.get("credits") or {}
    cast = []
    for person in sorted((p for p in credits.get("cast") or [] if isinstance(p, dict) and p.get("name")),
                         key=lambda p: p.get("order", 999))[:MAX_CAST]:
        profile = person.get("profile_path")
        cast.append([person["name"].strip(), (person.get("character") or "").strip(),
                     profile if isinstance(profile, str) and _IMAGE_PATH.match(profile) else None])
    crew = [c for c in credits.get("crew") or [] if isinstance(c, dict)]
    directors = _names([c for c in crew if c.get("job") == "Director"])
    writers = _names([c for c in crew if c.get("department") == "Writing"], limit=MAX_WRITERS)
    if kind == "tvshow":
        directors = directors or _names(data.get("created_by"))
        studios = _names(data.get("networks")) + [s for s in _names(data.get("production_companies"))
                                                  if s not in _names(data.get("networks"))]
        premiered = data.get("first_air_date")
        original = data.get("original_name")
    else:
        studios = _names(data.get("production_companies"))
        premiered = data.get("release_date")
        original = data.get("original_title")
    votes = data.get("vote_count") or 0
    rating = data.get("vote_average")
    return {
        "cast": cast,
        "directors": directors,
        "writers": writers,
        "studios": studios,
        "countries": _names(data.get("production_countries")),
        "tagline": (data.get("tagline") or "").strip(),
        "overview": (data.get("overview") or "").strip(),
        "original_title": (original or "").strip(),
        "premiered": premiered if isinstance(premiered, str) and _DATE.match(premiered) else None,
        "rating": [round(float(rating), 1), int(votes)] if votes and isinstance(rating, (int, float)) else None,
        "logo": pick_logo(data.get("images")),
    }


class Meta(object):
    """TMDB data of one title, as the router uses it."""

    def __init__(self, record):
        self.cast = [{"name": n, "role": r, "thumb": IMAGE_BASE + PROFILE_SIZE + p if p else "", "order": i}
                     for i, (n, r, p) in enumerate(record.get("cast") or [])]
        self.directors = record.get("directors") or []
        self.writers = record.get("writers") or []
        self.studios = record.get("studios") or []
        self.countries = record.get("countries") or []
        self.tagline = record.get("tagline") or ""
        self.overview = record.get("overview") or ""
        self.original_title = record.get("original_title") or ""
        self.premiered = record.get("premiered")
        self.rating = tuple(record["rating"]) if record.get("rating") else None
        logo = record.get("logo")
        self.logo = IMAGE_BASE + LOGO_SIZE + logo if logo else None


class TmdbMeta(object):
    def __init__(self, credential, cache_path, user_agent="plugin.video.filmio", opener=urlopen,
                 clock=time.time, timeout=TIMEOUT, log=lambda msg: None):
        self._auth = auth(credential)
        self.cache_path = cache_path
        self.user_agent = user_agent
        self.opener = opener
        self.clock = clock
        self.timeout = timeout
        self.log = log
        self._cache = None
        self._dirty = False
        self._lock = threading.Lock()

    @property
    def enabled(self):
        return self._auth is not None

    # -- cache ----------------------------------------------------------------

    def _entries(self):
        with self._lock:
            if self._cache is None:
                try:
                    with open(self.cache_path, encoding="utf-8") as fh:
                        data = json.load(fh)
                    self._cache = data if isinstance(data, dict) else {}
                except (OSError, ValueError):
                    self._cache = {}
            return self._cache

    def save(self):
        """Write the cache if anything changed (expired entries are dropped)."""
        with self._lock:
            if not self._dirty or self._cache is None:
                return
            now = self.clock()
            fresh = {k: v for k, v in self._cache.items() if isinstance(v, dict) and now < v.get("until", 0)}
            self._dirty = False
        try:
            directory = os.path.dirname(self.cache_path)
            if directory and not os.path.isdir(directory):
                os.makedirs(directory)
            tmp = self.cache_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(fresh, fh, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, self.cache_path)
        except OSError as exc:
            self.log("TMDB cache not written: %s" % type(exc).__name__)

    @staticmethod
    def _key(kind, tmdb_id):
        return "%s:%s" % (kind, tmdb_id)

    def _lookup(self, key):
        """(known, record or None)."""
        entry = self._entries().get(key)
        if not isinstance(entry, dict) or self.clock() >= entry.get("until", 0):
            return False, None
        record = entry.get("data")
        return True, record if isinstance(record, dict) else None

    def _store(self, key, record, ttl):
        entries = self._entries()
        with self._lock:
            entries[key] = {"data": record, "until": self.clock() + ttl}
            self._dirty = True

    # -- public ---------------------------------------------------------------

    def cached(self, kind, tmdb_id):
        """Meta from the cache only (no network), or None."""
        if not self.enabled or not tmdb_id:
            return None
        _, record = self._lookup(self._key(kind, tmdb_id))
        return Meta(record) if record else None

    def fetch(self, kind, tmdb_id):
        """Meta, asking TMDB if nothing valid is cached; or None."""
        if not self.enabled or not tmdb_id or kind not in ("movie", "tvshow"):
            return None
        key = self._key(kind, tmdb_id)
        known, record = self._lookup(key)
        if not known:
            record, ttl = self._request(kind, tmdb_id)
            self._store(key, record, ttl)
            self.save()
        return Meta(record) if record else None

    def prefetch(self, refs, budget, workers=WORKERS):
        """Fetch the uncached (kind, tmdb id) pairs in parallel, waiting at most
        budget seconds. Returns finish(): call it after the listing is shown
        to let the remaining requests complete and save the cache."""
        if not self.enabled:
            return lambda: None
        todo, seen = [], set()
        for kind, tmdb_id in refs:
            key = self._key(kind, tmdb_id)
            if tmdb_id and kind in ("movie", "tvshow") and key not in seen and not self._lookup(key)[0]:
                seen.add(key)
                todo.append((kind, tmdb_id))
        if not todo:
            return lambda: None
        queue = list(todo)
        queue_lock = threading.Lock()

        def worker():
            while True:
                with queue_lock:
                    if not queue:
                        return
                    kind, tmdb_id = queue.pop(0)
                record, ttl = self._request(kind, tmdb_id)
                self._store(self._key(kind, tmdb_id), record, ttl)

        threads = [threading.Thread(target=worker, name="filmio-tmdb") for _ in range(min(workers, len(todo)))]
        for thread in threads:
            thread.daemon = True
            thread.start()
        deadline = time.monotonic() + budget
        for thread in threads:
            thread.join(max(0.0, deadline - time.monotonic()))
        done = sum(1 for kind, tmdb_id in todo if self._lookup(self._key(kind, tmdb_id))[0])
        self.log("TMDB prefetch: %d titles, %d ready within %.1fs" % (len(todo), done, budget))

        def finish():
            for thread in threads:
                thread.join()
            self.save()
        return finish

    def _request(self, kind, tmdb_id):
        headers, params = self._auth
        endpoint = "%s/%s/%d" % (API, "movie" if kind == "movie" else "tv", int(tmdb_id))
        query = urlencode([("language", "hu-HU"), ("append_to_response", "credits,images"),
                           ("include_image_language", "hu,null,en")] + params)
        hdrs = {"User-Agent": self.user_agent, "Accept": "application/json"}
        hdrs.update(headers)
        what = "%s/%s" % (kind, tmdb_id)  # never log the URL: it may carry the API key
        try:
            resp = self.opener(Request(endpoint + "?" + query, headers=hdrs), timeout=self.timeout)
            data = json.loads(resp.read().decode("utf-8"))
            record = extract(kind, data if isinstance(data, dict) else {})
        except HTTPError as exc:
            exc.close()
            self.log("TMDB %s -> HTTP %d" % (what, exc.code))
            return None, (NONE_TTL if exc.code == 404 else ERROR_TTL)
        except (URLError, OSError, ValueError, TypeError, AttributeError) as exc:
            self.log("TMDB %s -> %s" % (what, type(exc).__name__))
            return None, ERROR_TTL
        return record, FOUND_TTL
