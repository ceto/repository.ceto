"""External ID mapping: Filmio content id -> TMDB / IMDb ids.

The mapping is produced outside the add-on (docs/ideas/metadata-ids.md §9-10)
and published as a JSON file. The add-on downloads it from MAPPING_URL at
most once per MAX_AGE, keeps the last good copy in the profile folder, and
never lets a missing or broken mapping block browsing or playback.

Format, version 1:

    {
      "version": 1,
      "generated": "2026-10-09T12:00:00Z",
      "items": {
        "<filmio id>": {"type": "movie",  "tmdb": 123, "imdb": "tt0123456",
                        "imdbRating": 5.9, "imdbVotes": 1327, "rottenTomatoes": 68},
        "<filmio id>": {"type": "tvshow", "tmdb": 456}
      }
    }

"<filmio id>" is the CMS document id of a film (asset) or series, the same
"id" the catalogue lists use. "imdb", "imdbRating" (0-10), "imdbVotes" and
"rottenTomatoes" (Tomatometer, percent) are optional; invalid values and
unknown fields are ignored.

Pure Python: no Kodi imports.
"""
import json
import os
import re
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# Where the published mapping lives (generated weekly by
# https://github.com/ceto/filmio-mapping). Empty: the feature is off.
MAPPING_URL = "https://raw.githubusercontent.com/ceto/filmio-mapping/main/data/mapping.json"

FORMAT_VERSION = 1
MAX_AGE = 24 * 3600   # seconds between checks for a newer mapping
RETRY_AFTER = 3600    # seconds to wait after a failed download before trying again
TIMEOUT = 5           # seconds; a slow mapping host must not slow down browsing
MAX_SIZE = 20 * 1024 * 1024

TYPES = ("movie", "tvshow")
_IMDB = re.compile(r"^tt\d{5,10}$")


class Mapping(object):
    def __init__(self, items=None):
        self.items = items or {}

    def __len__(self):
        return len(self.items)

    def unique_ids(self, filmio_id, kind):
        """{"tmdb": "123", "imdb": "tt..."} for a film ("movie") or series
        ("tvshow"), or {} if unknown or of a different type."""
        entry = self.items.get(filmio_id)
        if not entry or entry["type"] != kind:
            return {}
        ids = {"tmdb": str(entry["tmdb"])}
        if entry.get("imdb"):
            ids["imdb"] = entry["imdb"]
        return ids

    def ratings(self, filmio_id, kind):
        """{"imdb": (rating, votes), "tomatometerallcritics": (0-10, 0)} with
        what the mapping has for a film or series; {} if nothing. Kodi keeps
        every rating on a 0-10 scale, so the Tomatometer percent is divided by 10."""
        entry = self.items.get(filmio_id)
        if not entry or entry["type"] != kind:
            return {}
        ratings = {}
        if "imdbRating" in entry:
            ratings["imdb"] = (entry["imdbRating"], entry.get("imdbVotes", 0))
        if "rottenTomatoes" in entry:
            ratings["tomatometerallcritics"] = (entry["rottenTomatoes"] / 10.0, 0)
        return ratings


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def parse(payload):
    """Validate a decoded mapping document. Bad entries are skipped; a wrong
    version or shape raises ValueError (the caller keeps its last good copy)."""
    if not isinstance(payload, dict) or payload.get("version") != FORMAT_VERSION:
        raise ValueError("unsupported mapping version")
    raw = payload.get("items")
    if not isinstance(raw, dict):
        raise ValueError("mapping has no items")
    items = {}
    for filmio_id, entry in raw.items():
        if not isinstance(filmio_id, str) or not isinstance(entry, dict):
            continue
        kind, tmdb, imdb = entry.get("type"), entry.get("tmdb"), entry.get("imdb")
        if kind not in TYPES or isinstance(tmdb, bool) or not isinstance(tmdb, int) or tmdb <= 0:
            continue
        clean = {"type": kind, "tmdb": tmdb}
        if isinstance(imdb, str) and _IMDB.match(imdb):
            clean["imdb"] = imdb
        rating, votes, tomato = entry.get("imdbRating"), entry.get("imdbVotes"), entry.get("rottenTomatoes")
        if _number(rating) and 0 < rating <= 10:
            clean["imdbRating"] = float(rating)
            if isinstance(votes, int) and not isinstance(votes, bool) and votes > 0:
                clean["imdbVotes"] = votes
        if isinstance(tomato, int) and not isinstance(tomato, bool) and 0 <= tomato <= 100:
            clean["rottenTomatoes"] = tomato
        items[filmio_id] = clean
    return Mapping(items)


class MappingStore(object):
    """Downloads, caches and loads the mapping.

    The cache file keeps the raw document plus its ETag and the time of the
    last check, so an unchanged mapping costs one conditional request a day.
    """

    def __init__(self, path, url=MAPPING_URL, user_agent="plugin.video.filmio", opener=urlopen,
                 clock=time.time, max_age=MAX_AGE, timeout=TIMEOUT, log=lambda msg: None):
        self.path = path
        self.url = url
        self.user_agent = user_agent
        self.opener = opener
        self.clock = clock
        self.max_age = max_age
        self.timeout = timeout
        self.log = log

    def load(self):
        if not self.url:
            return Mapping()
        cached = self._read_cache()
        if cached is None or self.clock() - cached.get("checked", 0) >= self.max_age:
            fresh = self._refresh(cached)
            if fresh is None:
                # Back off: keep the last good document (if any) and do not
                # retry on every listing while the host is unreachable.
                cached = dict(cached or {"etag": None, "document": None},
                              checked=self.clock() - self.max_age + RETRY_AFTER)
                self._write_cache(cached)
            else:
                cached = fresh
        try:
            return parse(cached["document"])
        except (KeyError, TypeError, ValueError):
            return Mapping()

    def _read_cache(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                cached = json.load(fh)
            return cached if isinstance(cached, dict) and "document" in cached else None
        except (OSError, ValueError):
            return None

    def _write_cache(self, cached):
        try:
            directory = os.path.dirname(self.path)
            if directory and not os.path.isdir(directory):
                os.makedirs(directory)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(cached, fh)
            os.replace(tmp, self.path)
        except OSError as exc:
            self.log("mapping cache not written: %s" % type(exc).__name__)

    def _refresh(self, cached):
        """Fetch a newer mapping. Returns the new cache entry, or None to keep
        using the old one (or nothing) after a failure."""
        headers = {"User-Agent": self.user_agent, "Accept": "application/json"}
        if cached and cached.get("etag") and cached.get("document") is not None:
            headers["If-None-Match"] = cached["etag"]
        try:
            resp = self.opener(Request(self.url, headers=headers), timeout=self.timeout)
            body = resp.read(MAX_SIZE + 1)
            etag = resp.headers.get("ETag") if getattr(resp, "headers", None) else None
        except HTTPError as exc:
            exc.close()
            if exc.code == 304 and cached and cached.get("document") is not None:
                cached = dict(cached, checked=self.clock())
                self._write_cache(cached)
                self.log("mapping unchanged")
                return cached
            self.log("mapping download failed: HTTP %d" % exc.code)
            return None
        except (URLError, OSError) as exc:
            self.log("mapping download failed: %s" % type(exc).__name__)
            return None
        if len(body) > MAX_SIZE:
            self.log("mapping download ignored: larger than %d bytes" % MAX_SIZE)
            return None
        try:
            document = json.loads(body.decode("utf-8"))
            count = len(parse(document))
        except (UnicodeDecodeError, ValueError) as exc:
            self.log("mapping download ignored: %s" % exc)
            return None
        cached = {"checked": self.clock(), "etag": etag, "document": document}
        self._write_cache(cached)
        self.log("mapping updated (%d entries)" % count)
        return cached
