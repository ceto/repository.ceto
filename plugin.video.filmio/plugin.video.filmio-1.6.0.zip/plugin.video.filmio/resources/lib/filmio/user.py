"""Per-user actions on the catalogue ("Saját lista" bookmarks).

Verified against the official web client: the bookmark is added with the
content id and removed by the same content id.

- POST   {CMS}/user/bookmarks            {assetId, title, collectionType, locale}
- DELETE {CMS}/user/bookmarks/{assetId}

Pure Python: no Kodi imports.
"""
from urllib.parse import quote


class UserApi(object):
    def __init__(self, session, cms_base_url):
        """session: an auth.AuthSession (authorised request_json with refresh)."""
        self.session = session
        self.base = cms_base_url.rstrip("/")

    def add_bookmark(self, content_id, title, collection_type, locale="hu"):
        self.session.request_json("POST", self.base + "/user/bookmarks", body={
            "assetId": content_id, "title": title or "",
            "collectionType": collection_type, "locale": locale,
        })

    def remove_bookmark(self, content_id):
        self.session.request_json("DELETE", "%s/user/bookmarks/%s" % (self.base, quote(content_id, safe="")))
