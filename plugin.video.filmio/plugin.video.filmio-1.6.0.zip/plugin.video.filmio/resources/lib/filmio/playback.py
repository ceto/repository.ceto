"""Stream retrieval, InputStream Adaptive properties and the playback-session
schedule. Verified against the official web player (docs/feasibility.md §12):

- GET  {CMS}/videos/vod/v2/dashdrm/{videoId}  -> data.{url, drm_proxy_url, session{sessionId, userId}}
- POST {CMS}/videos/vod/session/heartbeat     {userId, sessionId}   every 5 s while playing
- POST {CMS}/videos/vod/session/stop          {userId, sessionId}   when playback ends
- POST {CMS}/user/views/track                 {userId, assetId, title, uid, length, position, locale}

The manifest and the Widevine license URL carry their access token in the
path, so no request headers are needed for them. The license exchange is a
plain Widevine POST, which is inputstream.adaptive's default behaviour.

Pure Python: no Kodi imports.
"""
import threading

from filmio.http import HttpError, ParseError

STREAM_FORMAT = "dashdrm"
WIDEVINE = "com.widevine.alpha"
MIME_DASH = "application/dash+xml"
ASSET_UID = "api::asset.asset"

HEARTBEAT_INTERVAL = 5.0   # seconds; matches the web player
TRACK_INTERVAL = 30.0      # seconds; the web player uses 5, which is more than needed
MIN_TRACK_POSITION = 15.0  # seconds; below this a "playback" is most likely a failed start


class SessionGone(Exception):
    """The server no longer knows the playback session (HTTP 410)."""


class Stream(object):
    def __init__(self, url, license_url, session_id, user_id):
        self.url = url
        self.license_url = license_url
        self.session_id = session_id
        self.user_id = user_id


def stream_from(payload):
    data = (payload or {}).get("data") or {}
    url = data.get("url")
    license_url = data.get("drm_proxy_url") or data.get("drmProxyUrl")
    session = data.get("session") or {}
    if not url or not license_url:
        raise ParseError("stream response without manifest or license URL")
    return Stream(url, license_url, session.get("sessionId"), session.get("userId"))


def isa_properties(stream):
    """ListItem properties for inputstream.adaptive (Kodi 21+): the license URL
    alone is enough, exactly as the web player does it. Verified on Android
    (system Widevine, L1). Extra headers or a service certificate did not help
    on desktop, and the certificate broke DRM setup on Android, so neither is
    sent (docs/feasibility.md §14-16)."""
    return {
        "inputstream": "inputstream.adaptive",
        "inputstream.adaptive.drm_legacy": "%s|%s" % (WIDEVINE, stream.license_url),
    }


class PlaybackApi(object):
    def __init__(self, session, cms_base_url):
        """session: an auth.AuthSession (authorised request_json with refresh)."""
        self.session = session
        self.base = cms_base_url.rstrip("/")

    def stream(self, video_id):
        return stream_from(self.session.request_json(
            "GET", "%s/videos/vod/v2/%s/%s" % (self.base, STREAM_FORMAT, video_id)))

    def heartbeat(self, stream):
        self._session_call("heartbeat", stream)

    def stop(self, stream):
        self._session_call("stop", stream)

    def _session_call(self, what, stream):
        if not stream.session_id or not stream.user_id:
            return
        try:
            self.session.request_json("POST", "%s/videos/vod/session/%s" % (self.base, what),
                                      body={"userId": stream.user_id, "sessionId": stream.session_id})
        except HttpError as exc:
            if exc.status == 410:
                raise SessionGone()
            raise

    def track(self, stream, asset_id, title, length, position, locale="hu"):
        if not stream.user_id or not asset_id:
            return
        self.session.request_json("POST", "%s/user/views/track" % self.base, body={
            "userId": stream.user_id, "assetId": asset_id, "title": title or "",
            "uid": ASSET_UID, "length": int(length or 0), "position": int(position or 0),
            "locale": locale,
        })


class Schedule(object):
    """Decides when to save progress while playing: every TRACK_INTERVAL, and
    immediately when playback pauses, so resume points stay accurate.
    (Heartbeats run on their own thread, see Heartbeat.)"""

    def __init__(self, start, track_interval=TRACK_INTERVAL):
        self.track_interval = track_interval
        self.next_track = start + track_interval
        self.was_playing = True

    def due(self, now, playing):
        actions = []
        paused_now = self.was_playing and not playing
        if (playing and now >= self.next_track) or paused_now:
            actions.append("track")
            self.next_track = now + self.track_interval
        self.was_playing = playing
        return actions


class Heartbeat(object):
    """Keeps the server-side playback session alive: api.heartbeat(stream)
    every interval seconds on a background thread.

    It only does HTTP, no Kodi calls, so slow player queries (seen on Android
    during playback) cannot delay it."""

    def __init__(self, api, stream, interval=HEARTBEAT_INTERVAL, log=lambda msg: None):
        self.api = api
        self.stream = stream
        self.interval = interval
        self.log = log
        self._stop = threading.Event()
        self._thread = None
        self.sent = 0

    def start(self):
        self._thread = threading.Thread(target=self._run, name="filmio-heartbeat")
        self._thread.daemon = True
        self._thread.start()
        return self

    def _run(self):
        while not self._stop.wait(self.interval):
            try:
                self.api.heartbeat(self.stream)
                self.sent += 1
            except SessionGone:
                self.log("playback session expired on the server; heartbeats stopped")
                return
            except Exception as exc:  # keep trying; the next tick retries
                self.log("heartbeat failed: %s" % type(exc).__name__)

    def stop(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(self.interval + 2)


# Player states reported by the state() callback of keep_alive().
STARTING, PLAYING, PAUSED, ENDED, ABORTED = "starting", "playing", "paused", "ended", "aborted"


def keep_alive(api, stream, asset_id, title, length, state, wait, clock,
               start_timeout=90.0, log=lambda msg: None, locale="hu", heartbeat=None):
    """Run the playback session until the player is done.

    state() -> (one of the states above, position in seconds or None)
    wait(seconds) -> True when Kodi asks the add-on to abort
    clock() -> monotonic seconds
    heartbeat: object with start()/stop() (default: a Heartbeat thread)

    Heartbeats run from the moment the stream is open (the server counts the
    session from the stream request), progress only once playback started.
    """
    heartbeat = heartbeat or Heartbeat(api, stream, log=log)
    heartbeat.start()
    start = clock()
    schedule = Schedule(start)
    started = False
    position = 0.0
    try:
        while True:
            current, pos = state()
            if current in (ABORTED, ENDED):
                break
            if current in (PLAYING, PAUSED):
                started = True
                if pos is not None:
                    position = pos
            elif not started and clock() - start > start_timeout:
                log("playback did not start within %ds" % start_timeout)
                break
            if started and schedule.due(clock(), current == PLAYING):
                try:
                    api.track(stream, asset_id, title, length, position, locale)
                except Exception as exc:  # keep playing; the next tick retries
                    log("track failed: %s" % type(exc).__name__)
            if wait(1.0):
                break
    finally:
        heartbeat.stop()
    # A start that never got past the first seconds (e.g. no license, so
    # nothing could be decrypted) must not overwrite the user's resume point.
    if started and position >= MIN_TRACK_POSITION:
        try:
            api.track(stream, asset_id, title, length, position, locale)
        except Exception as exc:
            log("final progress update failed: %s" % type(exc).__name__)
    try:
        api.stop(stream)
    except SessionGone:
        pass
    except Exception as exc:
        log("session stop failed: %s" % type(exc).__name__)
    return started, position
