"""Client for Filmio's public catalogue API (Strapi CMS). No login needed.

Endpoints and quirks are documented in docs/feasibility.md section 5.
"""
from filmio import models
from filmio.http import ParseError

BASE_URL = "https://cms-prod-filmio.connectmedia.hu/api"
DEFAULT_PAGE_SIZE = 50

# Values for the filter query parameters of "order" carousels. Genre and tag
# filters take the human-readable title, release-date filters the slug.
FILTER_KEYS = ("genres", "tags", "releaseDate")


def _parse(fn, payload, *args):
    try:
        return fn(payload, *args)
    except (AttributeError, KeyError, TypeError, ValueError) as exc:
        raise ParseError("unexpected %s: %s" % (fn.__name__, type(exc).__name__))


class CmsClient(object):
    """http serves anonymous calls (config, navigation, dashboards), as the
    official client does. user_http, when given, serves the calls that carry
    per-user data (carousels, series): authorised when signed in."""

    def __init__(self, http, base_url=BASE_URL, lang="Magyar", user_http=None, session=None):
        self.http = http
        self.user_http = user_http or http
        self.session = session
        self.base_url = base_url.rstrip("/")
        self.lang = lang

    @property
    def signed_in(self):
        return bool(self.session and self.session.signed_in)

    def _get(self, path, params=None):
        return self.http.get_json(self.base_url + path, params=params)

    def _get_user(self, path, params=None):
        return self.user_http.get_json(self.base_url + path, params=params)

    def config(self):
        return (self._get("/config") or {}).get("data") or {}

    def search_carousel_id(self):
        search = (self.config().get("app") or {}).get("search") or {}
        return search.get("searchCarouselId")

    def navigation(self, key="web"):
        return _parse(models.navigation_from, self._get("/navigation/tree/%s" % key))

    def dashboard(self, dashboard_id):
        return _parse(models.dashboard_from, self._get("/dashboards/%s" % dashboard_id, {"populate": "*"}))

    def carousel(self, carousel_id, page=1, page_size=DEFAULT_PAGE_SIZE, query=None,
                 filters=None, no_cache=False):
        params = [("page", page), ("pageSize", page_size)]
        if no_cache:
            params.append(("noCache", 1))
        if query:
            params.append(("q", query))
        for key in FILTER_KEYS:
            value = (filters or {}).get(key)
            if value:
                params.append((key, value))
        return _parse(models.page_from, self._get_user("/carousels/%s" % carousel_id, params), self.lang)

    def search(self, query, page=1, page_size=DEFAULT_PAGE_SIZE, carousel_id=None):
        carousel_id = carousel_id or self.search_carousel_id()
        if not carousel_id:
            raise ParseError("config has no search carousel")
        return self.carousel(carousel_id, page, page_size, query=query, no_cache=True)

    def asset(self, asset_id):
        """Detail of a film or episode (carries videoId, which lists lack)."""
        payload = self._get_user("/assets/%s" % asset_id)
        title = _parse(lambda p, lang: models.title_from((p or {}).get("data"), lang), payload, self.lang)
        if title is None:
            raise ParseError("asset without a known type")
        return title

    def series(self, series_id):
        return _parse(models.series_from, self._get_user("/series/%s" % series_id), self.lang)

    def films_dashboard_id(self):
        """The Films dashboard hosts the genre/tag/decade filters for movies."""
        for entry in self.navigation():
            if entry.path.rstrip("/") == "/filmek":
                return entry.dashboard_id
        return None
