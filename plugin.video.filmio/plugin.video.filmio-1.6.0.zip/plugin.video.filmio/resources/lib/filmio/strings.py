"""Reads a Kodi strings.po, so the add-on can show its own texts in Hungarian
whatever language Kodi's interface uses.

Pure Python: no Kodi imports.
"""
import re

_ENTRY = re.compile(r'msgctxt "#(\d+)"\s*\nmsgid "((?:[^"\\]|\\.)*)"\s*\nmsgstr "((?:[^"\\]|\\.)*)"')
_ESCAPES = {"n": "\n", "t": "\t", '"': '"', "\\": "\\"}


def _unescape(text):
    return re.sub(r"\\(.)", lambda m: _ESCAPES.get(m.group(1), m.group(1)), text)


def parse_po(text):
    """{string id: translation}; an empty msgstr falls back to the msgid."""
    return {int(sid): _unescape(msgstr or msgid) for sid, msgid, msgstr in _ENTRY.findall(text)}


def load_po(path):
    """parse_po() of a file; {} if it cannot be read."""
    try:
        with open(path, encoding="utf-8") as fh:
            return parse_po(fh.read())
    except (OSError, ValueError):
        return {}
